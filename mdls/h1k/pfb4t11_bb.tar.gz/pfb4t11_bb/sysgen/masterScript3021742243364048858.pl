
open(PIDFILE, '> pidfile.txt') || die 'Couldn\'t write process ID to file.';
print PIDFILE "$$\n";
close(PIDFILE);

eval {
  # Call script(s).
  my $instrs;
  my $results = [];
$ENV{'SYSGEN'} = '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen';
  use Sg;
  $instrs = {
    'HDLCodeGenStatus' => 0.0,
    'HDL_PATH' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k',
    'Impl_file' => 'ISE Defaults',
    'Impl_file_sgadvanced' => '',
    'Synth_file' => 'XST Defaults',
    'Synth_file_sgadvanced' => '',
    'TEMP' => '/tmp',
    'TMP' => '/tmp',
    'Temp' => '/tmp',
    'Tmp' => '/tmp',
    'base_system_period_hardware' => 10.0,
    'base_system_period_simulink' => 1.0,
    'block_icon_display' => 'Default',
    'block_type' => 'sysgen',
    'block_version' => '',
    'ce_clr' => 0.0,
    'clock_domain' => 'default',
    'clock_loc' => '',
    'clock_wrapper' => 'Clock Enables',
    'clock_wrapper_sgadvanced' => '',
    'compilation' => 'NGC Netlist',
    'compilation_lut' => {
      'keys' => [
        'HDL Netlist',
        'NGC Netlist',
      ],
      'values' => [
        'target1',
        'target2',
      ],
    },
    'compilation_target' => 'NGC Netlist',
    'core_generation' => 1.0,
    'core_generation_sgadvanced' => '',
    'core_is_deployed' => 0.0,
    'coregen_core_generation_tmpdir' => '/tmp/sysgentmp-ptcs/cg_wk/c3dab85ea8ed7452e',
    'coregen_part_family' => 'virtex6',
    'createTestbench' => 0,
    'create_interface_document' => 'off',
    'dbl_ovrd' => -1.0,
    'dbl_ovrd_sgadvanced' => '',
    'dcm_input_clock_period' => 10.0,
    'deprecated_control' => 'off',
    'deprecated_control_sgadvanced' => '',
    'design' => 'pfb4t11_bb',
    'design_full_path' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb.mdl',
    'device' => 'xc6vsx475t-1ff1759',
    'device_speed' => '-1',
    'directory' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb',
    'dsp_cache_root_path' => '/tmp/sysgentmp-ptcs',
    'eval_field' => '0',
    'fileDeliveryDefaults' => [
      [
        '(?i)\\.vhd$',
        { 'fileName' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/perl_results.vhd', },
      ],
      [
        '(?i)\\.v$',
        { 'fileName' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/perl_results.v', },
      ],
    ],
    'fxdptinstalled' => 1.0,
    'generateUsing71FrontEnd' => 1,
    'generating_island_subsystem_handle' => 187614.00610351562,
    'generating_subsystem_handle' => 187614.00610351562,
    'generation_directory' => './pfb4t11_bb',
    'has_advanced_control' => '0',
    'hdlDir' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl',
    'hdlKind' => 'vhdl',
    'hdl_path' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k',
    'impl_file' => 'ISE Defaults*',
    'incr_netlist' => 'off',
    'incr_netlist_sgadvanced' => '',
    'infoedit' => ' System Generator',
    'isdeployed' => 0,
    'ise_version' => '14.6i',
    'master_sysgen_token_handle' => 187615.00244140625,
    'matlab' => '/opt/matlab-R2012b',
    'matlab_fixedpoint' => 1.0,
    'mdlHandle' => 187614.00610351562,
    'mdlPath' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb.mdl',
    'modelDiagnostics' => [
      {
        'count' => 2445.0,
        'isMask' => 0.0,
        'type' => 'pfb4t11_bb Total blocks',
      },
      {
        'count' => 17.0,
        'isMask' => 0.0,
        'type' => 'Constant',
      },
      {
        'count' => 2.0,
        'isMask' => 0.0,
        'type' => 'DiscretePulseGenerator',
      },
      {
        'count' => 417.0,
        'isMask' => 0.0,
        'type' => 'Inport',
      },
      {
        'count' => 417.0,
        'isMask' => 0.0,
        'type' => 'Outport',
      },
      {
        'count' => 1283.0,
        'isMask' => 0.0,
        'type' => 'S-Function',
      },
      {
        'count' => 290.0,
        'isMask' => 0.0,
        'type' => 'SubSystem',
      },
      {
        'count' => 19.0,
        'isMask' => 0.0,
        'type' => 'Terminator',
      },
      {
        'count' => 48.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Adder/Subtracter Block',
      },
      {
        'count' => 96.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Arithmetic Relational Operator Block',
      },
      {
        'count' => 96.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bit Slice Extractor Block',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bus Concatenator Block',
      },
      {
        'count' => 48.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bus Multiplexer Block',
      },
      {
        'count' => 240.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Constant Block Block',
      },
      {
        'count' => 112.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Counter Block',
      },
      {
        'count' => 129.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Delay Block',
      },
      {
        'count' => 17.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway In Block',
      },
      {
        'count' => 17.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway Out Block',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Input Scaler Block',
      },
      {
        'count' => 48.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Logical Block Block',
      },
      {
        'count' => 64.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Multiplier Block',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Register Block',
      },
      {
        'count' => 48.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Single Port Random Access Memory Block',
      },
      {
        'count' => 64.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Single Port Read-Only Memory Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx System Generator Block',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Converter Block',
      },
      {
        'count' => 192.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Reinterpreter Block',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'adder_tree',
      },
      {
        'count' => 48.0,
        'isMask' => 1.0,
        'type' => 'delay_bram',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'first_tap_real',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'last_tap_real',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'pfb_coeff_gen',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'pfb_fir_real',
      },
      {
        'count' => 32.0,
        'isMask' => 1.0,
        'type' => 'pfb_tap_real',
      },
      {
        'count' => 48.0,
        'isMask' => 1.0,
        'type' => 'sync_delay',
      },
    ],
    'model_globals_initialized' => 1.0,
    'model_path' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb.mdl',
    'myxilinx' => '/opt/Xilinx/14.6/ISE_DS/ISE',
    'ngc_config' => {
      'include_cf' => 1.0,
      'include_clockwrapper' => 0.0,
    },
    'ngc_files' => [ 'xlpersistentdff.ngc', ],
    'num_sim_cycles' => '10',
    'package' => 'ff1759',
    'part' => 'xc6vsx475t',
    'partFamily' => 'virtex6',
    'port_data_types_enabled' => 1.0,
    'postgeneration_fcn' => 'xlNGCPostGeneration',
    'preserve_hierarchy' => 0.0,
    'proj_type' => 'Project Navigator',
    'proj_type_sgadvanced' => '',
    'run_coregen' => 'off',
    'run_coregen_sgadvanced' => '',
    'sample_time_colors_enabled' => 0.0,
    'sampletimecolors' => 0.0,
    'settings_fcn' => 'xlngcsettings',
    'sg_blockgui_xml' => '',
    'sg_icon_stat' => '50,50,-1,-1,token,white,0,07734,right,,[ ],[ ]',
    'sg_list_contents' => '',
    'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 50 50 0 0 ],[0 0 50 50 0 ],[1 1 1 ]);
patch([1.6375 16.81 27.31 37.81 48.31 27.31 12.1375 1.6375 ],[36.655 36.655 47.155 36.655 47.155 47.155 47.155 36.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 27.31 16.81 1.6375 12.1375 ],[26.155 26.155 36.655 36.655 26.155 ],[0.698039 0.0313725 0.219608 ]);
patch([1.6375 16.81 27.31 12.1375 1.6375 ],[15.655 15.655 26.155 26.155 15.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 48.31 37.81 27.31 16.81 1.6375 12.1375 ],[5.155 5.155 15.655 5.155 15.655 15.655 5.155 ],[0.698039 0.0313725 0.219608 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');',
    'sg_version' => '',
    'sggui_pos' => '-1,-1,-1,-1',
    'simulation_island_subsystem_handle' => 187614.00610351562,
    'simulink_accelerator_running' => 0.0,
    'simulink_debugger_running' => 0.0,
    'simulink_period' => 1.0,
    'speed' => '-1',
    'synth_file' => 'XST Defaults*',
    'synthesisTool' => 'XST',
    'synthesis_language' => 'vhdl',
    'synthesis_tool' => 'XST',
    'synthesis_tool_sgadvanced' => '',
    'sysclk_period' => 10.0,
    'sysgen' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen',
    'sysgenRoot' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen',
    'sysgenTokenSettings' => {
      'Impl_file' => 'ISE Defaults',
      'Impl_file_sgadvanced' => '',
      'Synth_file' => 'XST Defaults',
      'Synth_file_sgadvanced' => '',
      'base_system_period_hardware' => 10.0,
      'base_system_period_simulink' => 1.0,
      'block_icon_display' => 'Default',
      'block_type' => 'sysgen',
      'block_version' => '',
      'ce_clr' => 0.0,
      'clock_loc' => '',
      'clock_wrapper' => 'Clock Enables',
      'clock_wrapper_sgadvanced' => '',
      'compilation' => 'NGC Netlist',
      'compilation_lut' => {
        'keys' => [
          'HDL Netlist',
          'NGC Netlist',
        ],
        'values' => [
          'target1',
          'target2',
        ],
      },
      'core_generation' => 1.0,
      'core_generation_sgadvanced' => '',
      'coregen_part_family' => 'virtex6',
      'create_interface_document' => 'off',
      'dbl_ovrd' => -1.0,
      'dbl_ovrd_sgadvanced' => '',
      'dcm_input_clock_period' => 10.0,
      'deprecated_control' => 'off',
      'deprecated_control_sgadvanced' => '',
      'directory' => './pfb4t11_bb',
      'eval_field' => '0',
      'has_advanced_control' => '0',
      'impl_file' => 'ISE Defaults*',
      'incr_netlist' => 'off',
      'incr_netlist_sgadvanced' => '',
      'infoedit' => ' System Generator',
      'master_sysgen_token_handle' => 187615.00244140625,
      'ngc_config' => {
        'include_cf' => 1.0,
        'include_clockwrapper' => 0.0,
      },
      'package' => 'ff1759',
      'part' => 'xc6vsx475t',
      'postgeneration_fcn' => 'xlNGCPostGeneration',
      'preserve_hierarchy' => 0.0,
      'proj_type' => 'Project Navigator',
      'proj_type_sgadvanced' => '',
      'run_coregen' => 'off',
      'run_coregen_sgadvanced' => '',
      'settings_fcn' => 'xlngcsettings',
      'sg_blockgui_xml' => '',
      'sg_icon_stat' => '50,50,-1,-1,token,white,0,07734,right,,[ ],[ ]',
      'sg_list_contents' => '',
      'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 50 50 0 0 ],[0 0 50 50 0 ],[1 1 1 ]);
patch([1.6375 16.81 27.31 37.81 48.31 27.31 12.1375 1.6375 ],[36.655 36.655 47.155 36.655 47.155 47.155 47.155 36.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 27.31 16.81 1.6375 12.1375 ],[26.155 26.155 36.655 36.655 26.155 ],[0.698039 0.0313725 0.219608 ]);
patch([1.6375 16.81 27.31 12.1375 1.6375 ],[15.655 15.655 26.155 26.155 15.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 48.31 37.81 27.31 16.81 1.6375 12.1375 ],[5.155 5.155 15.655 5.155 15.655 15.655 5.155 ],[0.698039 0.0313725 0.219608 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');',
      'sggui_pos' => '-1,-1,-1,-1',
      'simulation_island_subsystem_handle' => 187614.00610351562,
      'simulink_period' => 1.0,
      'speed' => '-1',
      'synth_file' => 'XST Defaults*',
      'synthesis_language' => 'vhdl',
      'synthesis_tool' => 'XST',
      'synthesis_tool_sgadvanced' => '',
      'sysclk_period' => 10.0,
      'testbench' => 0,
      'testbench_sgadvanced' => '',
      'trim_vbits' => 1.0,
      'trim_vbits_sgadvanced' => '',
      'xilinx_device' => 'xc6vsx475t-1ff1759',
      'xilinxfamily' => 'virtex6',
    },
    'sysgen_Root' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen',
    'systemClockPeriod' => 10.0,
    'tempdir' => '/tmp',
    'testbench' => 0,
    'testbench_sgadvanced' => '',
    'tmpDir' => '/opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen',
    'trim_vbits' => 1.0,
    'trim_vbits_sgadvanced' => '',
    'use_strict_names' => 1,
    'user_tips_enabled' => 0.0,
    'usertemp' => '/tmp/sysgentmp-ptcs',
    'using71Netlister' => 1,
    'verilog_files' => [
      'conv_pkg.v',
      'synth_reg.v',
      'synth_reg_w_init.v',
      'convert_type.v',
    ],
    'version' => '',
    'vhdl_files' => [
      'conv_pkg.vhd',
      'synth_reg.vhd',
      'synth_reg_w_init.vhd',
    ],
    'vsimtime' => '385.000000 ns',
    'write_port_labels_on_update' => 1.0,
    'xilinx' => '/opt/Xilinx/14.6/ISE_DS/ISE',
    'xilinx_device' => 'xc6vsx475t-1ff1759',
    'xilinx_family' => 'virtex6',
    'xilinx_package' => 'ff1759',
    'xilinx_part' => 'xc6vsx475t',
    'xilinxdevice' => 'xc6vsx475t-1ff1759',
    'xilinxfamily' => 'virtex6',
    'xilinxpart' => 'xc6vsx475t',
  };
  push(@$results, &Sg::setAttributes($instrs));
  use SgDeliverFile;
  $instrs = {
    'collaborationName' => 'conv_pkg.vhd',
    'sourceFile' => 'hdl/conv_pkg.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg.vhd',
    'sourceFile' => 'hdl/synth_reg.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg_w_init.vhd',
    'sourceFile' => 'hdl/synth_reg_w_init.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'xlpersistentdff.ngc',
    'sourceFile' => 'hdl/xlpersistentdff.ngc',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b63f0ce78fa140a9c3ae7d2c24f189b0',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_17_32: signed((26 - 1) downto 0);
  signal b_17_35: signed((26 - 1) downto 0);
  type array_type_op_mem_91_20 is array (0 to (1 - 1)) of signed((26 - 1) downto 0);
  signal op_mem_91_20: array_type_op_mem_91_20 := (
    0 => "00000000000000000000000000");
  signal op_mem_91_20_front_din: signed((26 - 1) downto 0);
  signal op_mem_91_20_back: signed((26 - 1) downto 0);
  signal op_mem_91_20_push_front_pop_back_en: std_logic;
  type array_type_cout_mem_92_22 is array (0 to (1 - 1)) of unsigned((1 - 1) downto 0);
  signal cout_mem_92_22: array_type_cout_mem_92_22 := (
    0 => "0");
  signal cout_mem_92_22_front_din: unsigned((1 - 1) downto 0);
  signal cout_mem_92_22_back: unsigned((1 - 1) downto 0);
  signal cout_mem_92_22_push_front_pop_back_en: std_logic;
  signal prev_mode_93_22_next: unsigned((3 - 1) downto 0);
  signal prev_mode_93_22: unsigned((3 - 1) downto 0);
  signal prev_mode_93_22_reg_i: std_logic_vector((3 - 1) downto 0);
  signal prev_mode_93_22_reg_o: std_logic_vector((3 - 1) downto 0);
  signal cast_69_18: signed((27 - 1) downto 0);
  signal cast_69_22: signed((27 - 1) downto 0);
  signal internal_s_69_5_addsub: signed((27 - 1) downto 0);
  signal cast_internal_s_83_3_convert: signed((26 - 1) downto 0);
begin
  a_17_32 <= std_logic_vector_to_signed(a);
  b_17_35 <= std_logic_vector_to_signed(b);
  op_mem_91_20_back <= op_mem_91_20(0);
  proc_op_mem_91_20: process (clk)
  is
    variable i: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (op_mem_91_20_push_front_pop_back_en = \'1\')) then
        op_mem_91_20(0) <= op_mem_91_20_front_din;
      end if;
    end if;
  end process proc_op_mem_91_20;
  cout_mem_92_22_back <= cout_mem_92_22(0);
  proc_cout_mem_92_22: process (clk)
  is
    variable i_x_000000: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (cout_mem_92_22_push_front_pop_back_en = \'1\')) then
        cout_mem_92_22(0) <= cout_mem_92_22_front_din;
      end if;
    end if;
  end process proc_cout_mem_92_22;
  prev_mode_93_22_reg_i <= unsigned_to_std_logic_vector(prev_mode_93_22_next);
  prev_mode_93_22 <= std_logic_vector_to_unsigned(prev_mode_93_22_reg_o);
  prev_mode_93_22_reg_inst: entity work.synth_reg_w_init
    generic map (
      init_index => 2, 
      init_value => b"010", 
      latency => 1, 
      width => 3)
    port map (
      ce => ce, 
      clk => clk, 
      clr => clr, 
      i => prev_mode_93_22_reg_i, 
      o => prev_mode_93_22_reg_o);
  cast_69_18 <= s2s_cast(a_17_32, 24, 27, 24);
  cast_69_22 <= s2s_cast(b_17_35, 24, 27, 24);
  internal_s_69_5_addsub <= cast_69_18 + cast_69_22;
  cast_internal_s_83_3_convert <= s2s_cast(internal_s_69_5_addsub, 24, 26, 24);
  op_mem_91_20_front_din <= cast_internal_s_83_3_convert;
  op_mem_91_20_push_front_pop_back_en <= \'1\';
  cout_mem_92_22_front_din <= std_logic_vector_to_unsigned("0");
  cout_mem_92_22_push_front_pop_back_en <= \'1\';
  prev_mode_93_22_next <= std_logic_vector_to_unsigned("000");
  s <= signed_to_std_logic_vector(op_mem_91_20_back);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((26 - 1) downto 0);
    b : in std_logic_vector((26 - 1) downto 0);
    s : out std_logic_vector((26 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'addsub_14e4f27748',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c757019693f8032fa79ae996578cb9a4',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal d_1_22: std_logic;
  type array_type_op_mem_20_24 is array (0 to (2 - 1)) of std_logic;
  signal op_mem_20_24: array_type_op_mem_20_24 := (
    \'0\',
    \'0\');
  signal op_mem_20_24_front_din: std_logic;
  signal op_mem_20_24_back: std_logic;
  signal op_mem_20_24_push_front_pop_back_en: std_logic;
begin
  d_1_22 <= d(0);
  op_mem_20_24_back <= op_mem_20_24(1);
  proc_op_mem_20_24: process (clk)
  is
    variable i: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (op_mem_20_24_push_front_pop_back_en = \'1\')) then
        for i in 1 downto 1 loop 
          op_mem_20_24(i) <= op_mem_20_24(i-1);
        end loop;
        op_mem_20_24(0) <= op_mem_20_24_front_din;
      end if;
    end if;
  end process proc_op_mem_20_24;
  op_mem_20_24_front_din <= d_1_22;
  op_mem_20_24_push_front_pop_back_en <= \'1\';
  q <= std_logic_to_vector(op_mem_20_24_back);
end',
      'crippled_entity' => 'is
  port (
    d : in std_logic_vector((1 - 1) downto 0);
    q : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'delay_e18fb31a3d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  use SgGenerateCores;
  $instrs = [
    'SELECT Adder_Subtracter virtex6 Xilinx,_Inc. 11.0',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 27',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 27',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = true',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 1',
    'CSET Out_Width = 27',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'CSET component_name = addsb_11_0_d977443c01d8b65a',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '96e7b9a7821c87c388363a344fa9796b',
    'sourceFile' => 'hdl/xladdsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    a: in std_logic_vector(27 - 1 downto 0);
    clk: in std_logic:= \'0\';
    ce: in std_logic:= \'0\';
    s: out std_logic_vector(c_output_width - 1 downto 0);
    b: in std_logic_vector(27 - 1 downto 0)',
      'core_instance_text' => '         a => full_a,
         clk => clk,
         ce => internal_ce,
         s => core_s,
         b => full_b',
      'core_name0' => 'addsb_11_0_d977443c01d8b65a',
      'entityName' => 'xladdsub_pfb4t11_bb',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '65587d6f5e17dd6c6d12ea691beadc71',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal in0_1_23: unsigned((18 - 1) downto 0);
  signal in1_1_27: unsigned((18 - 1) downto 0);
  signal in2_1_31: unsigned((18 - 1) downto 0);
  signal in3_1_35: unsigned((18 - 1) downto 0);
  signal y_2_1_concat: unsigned((72 - 1) downto 0);
begin
  in0_1_23 <= std_logic_vector_to_unsigned(in0);
  in1_1_27 <= std_logic_vector_to_unsigned(in1);
  in2_1_31 <= std_logic_vector_to_unsigned(in2);
  in3_1_35 <= std_logic_vector_to_unsigned(in3);
  y_2_1_concat <= std_logic_vector_to_unsigned(unsigned_to_std_logic_vector(in0_1_23) & unsigned_to_std_logic_vector(in1_1_27) & unsigned_to_std_logic_vector(in2_1_31) & unsigned_to_std_logic_vector(in3_1_35));
  y <= unsigned_to_std_logic_vector(y_2_1_concat);
end',
      'crippled_entity' => 'is
  port (
    in0 : in std_logic_vector((18 - 1) downto 0);
    in1 : in std_logic_vector((18 - 1) downto 0);
    in2 : in std_logic_vector((18 - 1) downto 0);
    in3 : in std_logic_vector((18 - 1) downto 0);
    y : out std_logic_vector((72 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'concat_a246e373e7',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Binary_Counter virtex6 Xilinx,_Inc. 11.0',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = UP',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = false',
    'CSET output_width = 7',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_0c22adf9c6a5bc0d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'cfeb35c5ef5814a4bcc0cf9ff26e659b',
    'sourceFile' => 'hdl/xlcounter_free.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      clk: in std_logic;
      ce: in std_logic;
      SINIT: in std_logic;
      q: out std_logic_vector(op_width - 1 downto 0)',
      'core_instance_text' => '        clk => clk,
        ce => core_ce,
        SINIT => core_sinit,
        q => op_net',
      'core_name0' => 'cntr_11_0_0c22adf9c6a5bc0d',
      'entityName' => 'xlcounter_free_pfb4t11_bb',
      'entity_name.0' => 'xlcounter_free',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'df759c6728e5c399cd7fe87f3eadfde2',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFE9, 3FFC0, 3FF96, 3FF6B, 3FF40, 3FF15, 3FEE8, 3FEBB, 3FE8C, 3FE5D, 3FE2C, 3FDFA, 3FDC7, 3FD92, 3FD5C, 3FD24, 3FCEB, 3FCB0, 3FC73, 3FC34, 3FBF3, 3FBB0, 3FB6B, 3FB23, 3FADA, 3FA8E, 3FA40, 3F9F0, 3F99D, 3F947, 3F8F0, 3F895, 3F838, 3F7D9, 3F777, 3F713, 3F6AC, 3F642, 3F5D6, 3F568, 3F4F7, 3F483, 3F40E, 3F396, 3F31B, 3F29F, 3F220, 3F1A0, 3F11D, 3F099, 3F013, 3EF8B, 3EF02, 3EE78, 3EDEC, 3ED60, 3ECD2, 3EC44, 3EBB5, 3EB26, 3EA96, 3EA07, 3E978, 3E8E9, 3E85B, 3E7CD, 3E741, 3E6B7, 3E62E, 3E5A6, 3E521, 3E49F, 3E41F, 3E3A2, 3E328, 3E2B2, 3E240, 3E1D2, 3E168, 3E103, 3E0A4, 3E04A, 3DFF6, 3DFA8, 3DF60, 3DF20, 3DEE6, 3DEB5, 3DE8B, 3DE69, 3DE50, 3DE41, 3DE3A, 3DE3D, 3DE4B, 3DE63, 3DE85, 3DEB3, 3DEED, 3DF33, 3DF84, 3DFE3, 3E04E, 3E0C7, 3E14E, 3E1E3, 3E286, 3E338, 3E3F9, 3E4CA, 3E5AA, 3E69A, 3E79B, 3E8AD, 3E9CF, 3EB03, 3EC48, 3ED9F, 3EF09, 3F084, 3F212, 3F3B3, 3F567, 3F72F, 3F909, 3FAF8, 3FCFA, 3FF10;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_354e0cf0bb8a82b4',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '9174298235c2ef72889f60ed57ffa2bd',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_354e0cf0bb8a82b4',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 13A, 379, 5CC, 833, AB0, D40, FE6, 12A0, 1570, 1854, 1B4D, 1E5B, 217E, 24B6, 2802, 2B64, 2EDA, 3264, 3603, 39B6, 3D7D, 4159, 4548, 494A, 4D60, 5189, 55C5, 5A14, 5E75, 62E8, 676D, 6C03, 70AA, 7561, 7A29, 7F01, 83E8, 88DE, 8DE3, 92F6, 9816, 9D44, A27E, A7C4, AD16, B272, B7DA, BD4B, C2C5, C848, CDD3, D365, D8FE, DE9D, E442, E9EC, EF99, F54A, FAFE, 100B4, 1066B, 10C23, 111DA, 11791, 11D46, 122F9, 128A9, 12E54, 133FC, 1399E, 13F39, 144CE, 14A5C, 14FE1, 1555C, 15ACE, 16035, 16591, 16AE1, 17023, 17558, 17A7E, 17F96, 1849D, 18994, 18E79, 1934C, 1980D, 19CBA, 1A152, 1A5D6, 1AA44, 1AE9D, 1B2DE, 1B708, 1BB19, 1BF12, 1C2F2, 1C6B7, 1CA62, 1CDF2, 1D167, 1D4BF, 1D7FB, 1DB19, 1DE1A, 1E0FD, 1E3C1, 1E666, 1E8EC, 1EB52, 1ED98, 1EFBD, 1F1C2, 1F3A5, 1F567, 1F707, 1F885, 1F9E1, 1FB1B, 1FC32, 1FD26, 1FDF7, 1FEA5, 1FF30, 1FF98, 1FFDC, 1FFFD;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_87b808df8fb39edd',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '6876eb8716736b3e09f4f8d021c1750f',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_87b808df8fb39edd',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFA, 1FFD4, 1FF8B, 1FF1E, 1FE8F, 1FDDC, 1FD06, 1FC0D, 1FAF1, 1F9B2, 1F852, 1F6CF, 1F52A, 1F363, 1F17B, 1EF72, 1ED48, 1EAFD, 1E893, 1E609, 1E35F, 1E097, 1DDB0, 1DAAB, 1D788, 1D448, 1D0EC, 1CD74, 1C9E0, 1C631, 1C268, 1BE85, 1BA88, 1B673, 1B246, 1AE02, 1A9A6, 1A535, 1A0AE, 19C13, 19763, 192A0, 18DCA, 188E3, 183E9, 17EE0, 179C7, 1749E, 16F67, 16A23, 164D2, 15F74, 15A0C, 15499, 14F1C, 14996, 14407, 13E71, 138D5, 13332, 12D8A, 127DE, 1222E, 11C7B, 116C5, 1110F, 10B57, 105A0, FFE9, FA33, F480, EECF, E922, E37A, DDD6, D838, D29F, CD0E, C784, C203, BC8A, B71A, B1B5, AC5A, A70A, A1C5, 9C8D, 9761, 9243, 8D32, 8830, 833C, 7E57, 7981, 74BC, 7007, 6B62, 66CF, 624D, 5DDC, 597E, 5532, 50F9, 4CD3, 48BF, 44C0, 40D4, 3CFB, 3937, 3587, 31EB, 2E63, 2AF0, 2792, 2448, 2114, 1DF4, 1AE9, 17F3, 1512, 1245, F8E, CEB, A5D, 7E4, 580, 32F, F4;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_bac23c4ba2ca7f8b',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '767077d65dc44b5163f63606cb0d578d',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_bac23c4ba2ca7f8b',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FECC, 3FCB9, 3FABA, 3F8CE, 3F6F6, 3F532, 3F380, 3F1E2, 3F057, 3EEDE, 3ED77, 3EC22, 3EAE0, 3E9AE, 3E88E, 3E77F, 3E681, 3E592, 3E4B4, 3E3E6, 3E327, 3E277, 3E1D6, 3E143, 3E0BE, 3E047, 3DFDD, 3DF81, 3DF30, 3DEED, 3DEB5, 3DE88, 3DE67, 3DE50, 3DE44, 3DE42, 3DE4A, 3DE5B, 3DE75, 3DE98, 3DEC3, 3DEF5, 3DF30, 3DF71, 3DFBA, 3E008, 3E05D, 3E0B8, 3E118, 3E17D, 3E1E7, 3E256, 3E2C8, 3E33F, 3E3B9, 3E436, 3E4B6, 3E539, 3E5BF, 3E646, 3E6CF, 3E75A, 3E7E6, 3E873, 3E901, 3E990, 3EA1F, 3EAAF, 3EB3E, 3EBCD, 3EC5C, 3ECEA, 3ED77, 3EE03, 3EE8F, 3EF19, 3EFA2, 3F029, 3F0AF, 3F133, 3F1B5, 3F235, 3F2B3, 3F32F, 3F3A9, 3F420, 3F496, 3F508, 3F579, 3F5E7, 3F653, 3F6BC, 3F722, 3F786, 3F7E8, 3F846, 3F8A3, 3F8FD, 3F954, 3F9A9, 3F9FB, 3FA4C, 3FA99, 3FAE5, 3FB2E, 3FB75, 3FBB9, 3FBFC, 3FC3D, 3FC7B, 3FCB8, 3FCF3, 3FD2C, 3FD64, 3FD99, 3FDCE, 3FE01, 3FE33, 3FE63, 3FE92, 3FEC1, 3FEEE, 3FF1A, 3FF46, 3FF71, 3FF9B, 3FFC5, 3FFEE;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_6c2e599e357244f6',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '316b7cb5b08825442c3fa8164b8b7e2c',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_6c2e599e357244f6',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '7c72674b2b751038d6a194b0ffde09a7',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '6c5ae4ed7a90830b07c3ff2596ce4fc5',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal input_port_1_40: signed((18 - 1) downto 0);
  signal output_port_5_5_force: unsigned((18 - 1) downto 0);
begin
  input_port_1_40 <= std_logic_vector_to_signed(input_port);
  output_port_5_5_force <= signed_to_unsigned(input_port_1_40);
  output_port <= unsigned_to_std_logic_vector(output_port_5_5_force);
end',
      'crippled_entity' => 'is
  port (
    input_port : in std_logic_vector((18 - 1) downto 0);
    output_port : out std_logic_vector((18 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'reinterpret_580feec131',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6ad445b6f8877f9085a60086a6d52eff',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '13366d021ddc9f5413827bc05cb9e24f',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "1";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_6293007044',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ff98a0b5d9af518af21caef95683354e',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal count_reg_20_23: unsigned((7 - 1) downto 0) := "0000000";
  signal count_reg_20_23_rst: std_logic;
  signal rel_34_8: boolean;
  signal rst_limit_join_34_5: boolean;
  signal bool_44_4: boolean;
  signal rst_limit_join_44_1: boolean;
  signal count_reg_join_44_1: unsigned((8 - 1) downto 0);
  signal count_reg_join_44_1_rst: std_logic;
begin
  proc_count_reg_20_23: process (clk)
  is
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (count_reg_20_23_rst = \'1\')) then
        count_reg_20_23 <= "0000000";
      elsif (ce = \'1\') then 
        count_reg_20_23 <= count_reg_20_23 + std_logic_vector_to_unsigned("0000001");
      end if;
    end if;
  end process proc_count_reg_20_23;
  rel_34_8 <= count_reg_20_23 = std_logic_vector_to_unsigned("1111101");
  proc_if_34_5: process (rel_34_8)
  is
  begin
    if rel_34_8 then
      rst_limit_join_34_5 <= true;
    else 
      rst_limit_join_34_5 <= false;
    end if;
  end process proc_if_34_5;
  bool_44_4 <= false or rst_limit_join_34_5;
  proc_if_44_1: process (bool_44_4, count_reg_20_23, rst_limit_join_34_5)
  is
  begin
    if bool_44_4 then
      count_reg_join_44_1_rst <= \'1\';
    else 
      count_reg_join_44_1_rst <= \'0\';
    end if;
    if bool_44_4 then
      rst_limit_join_44_1 <= false;
    else 
      rst_limit_join_44_1 <= rst_limit_join_34_5;
    end if;
  end process proc_if_44_1;
  count_reg_20_23_rst <= count_reg_join_44_1_rst;
  op <= unsigned_to_std_logic_vector(count_reg_20_23);
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((7 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'counter_e8daa3c269',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_RAM',
    'CSET operating_mode_a = READ_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 8',
    'CSET read_width_b = 8',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 8',
    'CSET write_width_b = 8',
    'CSET component_name = bmg_72_cc52acd292e55386',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd5719572d2cc563176ef0ca2283993d1',
    'sourceFile' => 'hdl/xlspram.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      dina: in std_logic_vector(c_width - 1 downto 0);
      wea: in std_logic_vector(0 downto 0);
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => addr,
        clka => clk,
        dina => data_in,
        wea(0) => core_we,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_cc52acd292e55386',
      'entityName' => 'xlspram_pfb4t11_bb',
      'entity_name.0' => 'xlspram',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '318ca2555e00c36f456f01afe2e1e488',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_1_22: signed((8 - 1) downto 0);
  signal b_1_25: signed((18 - 1) downto 0);
  type array_type_op_mem_65_20 is array (0 to (2 - 1)) of signed((26 - 1) downto 0);
  signal op_mem_65_20: array_type_op_mem_65_20 := (
    "00000000000000000000000000",
    "00000000000000000000000000");
  signal op_mem_65_20_front_din: signed((26 - 1) downto 0);
  signal op_mem_65_20_back: signed((26 - 1) downto 0);
  signal op_mem_65_20_push_front_pop_back_en: std_logic;
  signal mult_46_56: signed((26 - 1) downto 0);
begin
  a_1_22 <= std_logic_vector_to_signed(a);
  b_1_25 <= std_logic_vector_to_signed(b);
  op_mem_65_20_back <= op_mem_65_20(1);
  proc_op_mem_65_20: process (clk)
  is
    variable i: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (op_mem_65_20_push_front_pop_back_en = \'1\')) then
        for i in 1 downto 1 loop 
          op_mem_65_20(i) <= op_mem_65_20(i-1);
        end loop;
        op_mem_65_20(0) <= op_mem_65_20_front_din;
      end if;
    end if;
  end process proc_op_mem_65_20;
  mult_46_56 <= (a_1_22 * b_1_25);
  op_mem_65_20_front_din <= mult_46_56;
  op_mem_65_20_push_front_pop_back_en <= \'1\';
  p <= signed_to_std_logic_vector(op_mem_65_20_back);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((8 - 1) downto 0);
    b : in std_logic_vector((18 - 1) downto 0);
    p : out std_logic_vector((26 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'mult_124cfbcd07',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7278cc6d2681503b42f7a4b4201bd1f5',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal input_port_1_40: unsigned((18 - 1) downto 0);
  signal output_port_5_5_force: signed((18 - 1) downto 0);
begin
  input_port_1_40 <= std_logic_vector_to_unsigned(input_port);
  output_port_5_5_force <= unsigned_to_signed(input_port_1_40);
  output_port <= signed_to_std_logic_vector(output_port_5_5_force);
end',
      'crippled_entity' => 'is
  port (
    input_port : in std_logic_vector((18 - 1) downto 0);
    output_port : out std_logic_vector((18 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'reinterpret_9a0fa0f632',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b873c30a4a165c6a2cca5bd2c036c837',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal input_port_1_40: signed((8 - 1) downto 0);
begin
  input_port_1_40 <= std_logic_vector_to_signed(input_port);
  output_port <= signed_to_std_logic_vector(input_port_1_40);
end',
      'crippled_entity' => 'is
  port (
    input_port : in std_logic_vector((8 - 1) downto 0);
    output_port : out std_logic_vector((8 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'reinterpret_d9988e3d87',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c10e24ba9077159d7ed32df4e1240c43',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e3734efc4b362e9d46cc979932e6c0dd',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '0eac7874fdd67fff6238c27810be33fb',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '6abdaaf6ef75e1d7cfd6e45ac70479e7',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c22761bb7a219809df62da1f0dbf6df4',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '55228f34c9366785e7d13e2dd5401d9e',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFE6, 3FFBD, 3FF93, 3FF69, 3FF3E, 3FF12, 3FEE5, 3FEB8, 3FE89, 3FE5A, 3FE29, 3FDF7, 3FDC4, 3FD8F, 3FD59, 3FD21, 3FCE7, 3FCAC, 3FC6F, 3FC30, 3FBEF, 3FBAC, 3FB66, 3FB1F, 3FAD5, 3FA89, 3FA3B, 3F9EA, 3F997, 3F942, 3F8EA, 3F88F, 3F833, 3F7D3, 3F771, 3F70C, 3F6A5, 3F63C, 3F5CF, 3F561, 3F4F0, 3F47C, 3F406, 3F38E, 3F314, 3F297, 3F218, 3F198, 3F115, 3F091, 3F00B, 3EF83, 3EEFA, 3EE6F, 3EDE4, 3ED57, 3ECC9, 3EC3B, 3EBAC, 3EB1D, 3EA8D, 3E9FE, 3E96F, 3E8E0, 3E852, 3E7C5, 3E739, 3E6AE, 3E625, 3E59E, 3E519, 3E496, 3E417, 3E39A, 3E320, 3E2AB, 3E239, 3E1CB, 3E162, 3E0FD, 3E09E, 3E045, 3DFF1, 3DFA3, 3DF5C, 3DF1C, 3DEE3, 3DEB2, 3DE88, 3DE67, 3DE4F, 3DE40, 3DE3A, 3DE3E, 3DE4C, 3DE65, 3DE88, 3DEB7, 3DEF1, 3DF37, 3DF8A, 3DFE9, 3E056, 3E0CF, 3E157, 3E1ED, 3E291, 3E344, 3E406, 3E4D7, 3E5B9, 3E6AA, 3E7AC, 3E8BE, 3E9E2, 3EB17, 3EC5D, 3EDB5, 3EF20, 3F09C, 3F22C, 3F3CE, 3F583, 3F74C, 3F928, 3FB17, 3FD1B, 3FF32;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_c4f63c93522ec796',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '2c4735bd05c88a9a460e7d57aa8a887a',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_c4f63c93522ec796',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 15E, 39D, 5F2, 85B, AD8, D6A, 1011, 12CD, 159D, 1883, 1B7D, 1E8D, 21B1, 24EA, 2838, 2B9A, 2F12, 329D, 363D, 39F2, 3DBA, 4197, 4587, 498B, 4DA2, 51CD, 560A, 5A5A, 5EBC, 6330, 67B5, 6C4C, 70F5, 75AD, 7A76, 7F4F, 8437, 892E, 8E34, 9347, 9869, 9D97, A2D2, A819, AD6B, B2C9, B830, BDA2, C31D, C8A0, CE2C, D3BE, D958, DEF8, E49D, EA46, EFF4, F5A5, FB59, 1010F, 106C6, 10C7E, 11236, 117EC, 11DA1, 12354, 12903, 12EAF, 13456, 139F8, 13F93, 14527, 14AB4, 15039, 155B4, 15B25, 1608B, 165E6, 16B35, 17077, 175AB, 17AD0, 17FE7, 184ED, 189E3, 18EC7, 19399, 19858, 19D04, 1A19B, 1A61E, 1AA8B, 1AEE1, 1B321, 1B749, 1BB5A, 1BF51, 1C32F, 1C6F3, 1CA9C, 1CE2A, 1D19D, 1D4F4, 1D82D, 1DB4A, 1DE49, 1E12A, 1E3EC, 1E68F, 1E913, 1EB77, 1EDBB, 1EFDE, 1F1E1, 1F3C2, 1F582, 1F720, 1F89C, 1F9F6, 1FB2D, 1FC42, 1FD34, 1FE03, 1FEAF, 1FF37, 1FF9D, 1FFDF, 1FFFE;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_95eb0dae0ef2619b',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'fde7b983ee9c5ff3a9dfee376b7a0096',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_95eb0dae0ef2619b',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFF9, 1FFD1, 1FF85, 1FF17, 1FE84, 1FDCF, 1FCF7, 1FBFC, 1FADE, 1F99D, 1F83A, 1F6B5, 1F50E, 1F345, 1F15B, 1EF50, 1ED24, 1EAD8, 1E86B, 1E5DF, 1E333, 1E069, 1DD80, 1DA79, 1D755, 1D413, 1D0B5, 1CD3B, 1C9A6, 1C5F5, 1C22A, 1BE46, 1BA48, 1B631, 1B203, 1ADBD, 1A960, 1A4ED, 1A065, 19BC8, 19717, 19253, 18D7C, 18893, 18399, 17E8F, 17974, 1744B, 16F13, 169CE, 1647C, 15F1E, 159B5, 15441, 14EC3, 1493D, 143AE, 13E18, 1387B, 132D8, 12D30, 12783, 121D3, 11C1F, 1166A, 110B3, 10AFC, 10544, FF8D, F9D8, F425, EE74, E8C8, E31F, DD7C, D7DE, D246, CCB5, C72C, C1AB, BC33, B6C4, B15F, AC04, A6B5, A171, 9C3A, 970F, 91F2, 8CE2, 87E0, 82ED, 7E09, 7935, 7470, 6FBC, 6B19, 6686, 6205, 5D96, 5939, 54EE, 50B6, 4C91, 487F, 4480, 4095, 3CBE, 38FB, 354C, 31B2, 2E2B, 2ABA, 275D, 2415, 20E1, 1DC3, 1AB9, 17C4, 14E4, 1219, F63, CC2, A35, 7BD, 55A, 30B, D1;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_278ddb29dc2fca2d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '52c36d540f37de483d1dcd203d3f2309',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_278ddb29dc2fca2d',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FEAB, 3FC98, 3FA9A, 3F8B0, 3F6D9, 3F516, 3F366, 3F1C9, 3F03E, 3EEC7, 3ED61, 3EC0E, 3EACC, 3E99C, 3E87D, 3E76F, 3E671, 3E584, 3E4A7, 3E3DA, 3E31C, 3E26D, 3E1CC, 3E13A, 3E0B6, 3E040, 3DFD7, 3DF7B, 3DF2C, 3DEE9, 3DEB1, 3DE86, 3DE65, 3DE4F, 3DE44, 3DE43, 3DE4B, 3DE5C, 3DE77, 3DE9A, 3DEC6, 3DEF9, 3DF34, 3DF76, 3DFBE, 3E00D, 3E063, 3E0BE, 3E11E, 3E184, 3E1EE, 3E25D, 3E2D0, 3E346, 3E3C1, 3E43E, 3E4BF, 3E542, 3E5C7, 3E64F, 3E6D8, 3E763, 3E7EF, 3E87C, 3E90A, 3E999, 3EA28, 3EAB8, 3EB47, 3EBD6, 3EC64, 3ECF3, 3ED80, 3EE0C, 3EE97, 3EF22, 3EFAA, 3F031, 3F0B7, 3F13B, 3F1BD, 3F23D, 3F2BB, 3F337, 3F3B0, 3F428, 3F49D, 3F510, 3F580, 3F5EE, 3F659, 3F6C2, 3F728, 3F78C, 3F7EE, 3F84C, 3F8A9, 3F902, 3F959, 3F9AE, 3FA01, 3FA50, 3FA9E, 3FAE9, 3FB32, 3FB79, 3FBBE, 3FC00, 3FC41, 3FC7F, 3FCBC, 3FCF6, 3FD30, 3FD67, 3FD9D, 3FDD1, 3FE04, 3FE36, 3FE66, 3FE95, 3FEC3, 3FEF1, 3FF1D, 3FF49, 3FF73, 3FF9E, 3FFC7, 3FFF1;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_83f6067bfd9a38e1',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b397fbefda4e506e6279a522fa22ab00',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_83f6067bfd9a38e1',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFE4, 3FFBA, 3FF90, 3FF66, 3FF3B, 3FF0F, 3FEE3, 3FEB5, 3FE87, 3FE57, 3FE26, 3FDF4, 3FDC1, 3FD8C, 3FD55, 3FD1D, 3FCE4, 3FCA8, 3FC6B, 3FC2C, 3FBEB, 3FBA7, 3FB62, 3FB1A, 3FAD1, 3FA85, 3FA36, 3F9E5, 3F992, 3F93D, 3F8E4, 3F88A, 3F82D, 3F7CD, 3F76B, 3F706, 3F69F, 3F635, 3F5C9, 3F55A, 3F4E8, 3F475, 3F3FF, 3F387, 3F30C, 3F28F, 3F210, 3F190, 3F10D, 3F088, 3F002, 3EF7A, 3EEF1, 3EE67, 3EDDB, 3ED4E, 3ECC0, 3EC32, 3EBA3, 3EB14, 3EA84, 3E9F5, 3E966, 3E8D7, 3E849, 3E7BC, 3E730, 3E6A5, 3E61D, 3E596, 3E511, 3E48E, 3E40F, 3E392, 3E319, 3E2A3, 3E232, 3E1C4, 3E15B, 3E0F7, 3E098, 3E03F, 3DFEC, 3DF9F, 3DF58, 3DF18, 3DEE0, 3DEAF, 3DE86, 3DE66, 3DE4E, 3DE3F, 3DE3A, 3DE3E, 3DE4D, 3DE66, 3DE8B, 3DEBA, 3DEF5, 3DF3C, 3DF8F, 3DFF0, 3E05D, 3E0D8, 3E160, 3E1F7, 3E29C, 3E34F, 3E412, 3E4E5, 3E5C7, 3E6BA, 3E7BD, 3E8D0, 3E9F5, 3EB2B, 3EC72, 3EDCC, 3EF37, 3F0B5, 3F245, 3F3E9, 3F59F, 3F769, 3F946, 3FB37, 3FD3B, 3FF54;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_147aa3d688eb91c6',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '769e10be9be38792d1999a5bb5c5a531',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_147aa3d688eb91c6',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 181, 3C2, 618, 882, B01, D94, 103C, 12F9, 15CB, 18B2, 1BAE, 1EBE, 21E4, 251E, 286D, 2BD1, 2F4A, 32D7, 3678, 3A2E, 3DF8, 41D5, 45C7, 49CC, 4DE4, 5210, 564E, 5A9F, 5F02, 6378, 67FE, 6C96, 7140, 75F9, 7AC3, 7F9D, 8486, 897E, 8E84, 9399, 98BB, 9DEA, A326, A86E, ADC1, B31F, B887, BDF9, C375, C8F9, CE85, D418, D9B2, DF52, E4F7, EAA1, F04F, F601, FBB5, 1016B, 10722, 10CDA, 11291, 11848, 11DFD, 123AF, 1295E, 12F0A, 134B0, 13A51, 13FEC, 14580, 14B0D, 15091, 1560B, 15B7C, 160E1, 1663C, 16B8A, 170CB, 175FE, 17B22, 18038, 1853D, 18A31, 18F14, 193E5, 198A3, 19D4E, 1A1E4, 1A665, 1AAD1, 1AF26, 1B364, 1B78B, 1BB9A, 1BF8F, 1C36C, 1C72E, 1CAD6, 1CE62, 1D1D3, 1D528, 1D860, 1DB7B, 1DE78, 1E157, 1E417, 1E6B9, 1E93A, 1EB9C, 1EDDE, 1F000, 1F200, 1F3DF, 1F59D, 1F739, 1F8B3, 1FA0A, 1FB40, 1FC52, 1FD42, 1FE0F, 1FEB8, 1FF3F, 1FFA2, 1FFE2, 1FFFE;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_62afd8462292912f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'baf62ea0ba788517181306a8ed0f36ab',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_62afd8462292912f',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFF7, 1FFCD, 1FF7F, 1FF0E, 1FE7A, 1FDC3, 1FCE8, 1FBEB, 1FACB, 1F988, 1F823, 1F69C, 1F4F3, 1F328, 1F13C, 1EF2E, 1ED00, 1EAB2, 1E843, 1E5B5, 1E308, 1E03B, 1DD51, 1DA48, 1D722, 1D3DE, 1D07E, 1CD03, 1C96B, 1C5B9, 1C1ED, 1BE06, 1BA07, 1B5EF, 1B1BF, 1AD77, 1A919, 1A4A5, 1A01C, 19B7E, 196CC, 19206, 18D2E, 18844, 18349, 17E3E, 17922, 173F8, 16EC0, 16979, 16427, 15EC8, 1595E, 153EA, 14E6B, 148E4, 14355, 13DBE, 13821, 1327D, 12CD5, 12728, 12178, 11BC4, 1160F, 11058, 10AA0, 104E9, FF32, F97D, F3CA, EE1A, E86D, E2C5, DD22, D784, D1ED, CC5D, C6D4, C153, BBDC, B66D, B109, ABAF, A661, A11E, 9BE7, 96BD, 91A0, 8C91, 8790, 829E, 7DBB, 78E8, 7424, 6F71, 6ACF, 663E, 61BE, 5D50, 58F4, 54AA, 5073, 4C4F, 483E, 4441, 4057, 3C82, 38C0, 3512, 3179, 2DF4, 2A83, 2728, 23E1, 20AF, 1D91, 1A89, 1795, 14B7, 11ED, F38, C98, A0D, 796, 534, 2E7, AE;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_6d72bb8f9e25db69',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '476522ad858cad4b4dceb909873e24df',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_6d72bb8f9e25db69',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FE89, 3FC78, 3FA7B, 3F892, 3F6BD, 3F4FA, 3F34B, 3F1B0, 3F026, 3EEB0, 3ED4B, 3EBF9, 3EAB8, 3E989, 3E86B, 3E75E, 3E662, 3E576, 3E49A, 3E3CD, 3E310, 3E262, 3E1C3, 3E132, 3E0AF, 3E039, 3DFD1, 3DF76, 3DF27, 3DEE5, 3DEAE, 3DE83, 3DE63, 3DE4E, 3DE44, 3DE43, 3DE4C, 3DE5E, 3DE79, 3DE9D, 3DEC9, 3DEFC, 3DF38, 3DF7A, 3DFC3, 3E013, 3E068, 3E0C4, 3E124, 3E18A, 3E1F5, 3E264, 3E2D7, 3E34E, 3E3C8, 3E446, 3E4C7, 3E54A, 3E5CF, 3E657, 3E6E1, 3E76B, 3E7F8, 3E885, 3E913, 3E9A2, 3EA31, 3EAC0, 3EB50, 3EBDF, 3EC6D, 3ECFB, 3ED89, 3EE15, 3EEA0, 3EF2A, 3EFB3, 3F03A, 3F0BF, 3F143, 3F1C5, 3F245, 3F2C3, 3F33E, 3F3B8, 3F42F, 3F4A4, 3F517, 3F587, 3F5F5, 3F660, 3F6C9, 3F72F, 3F792, 3F7F4, 3F852, 3F8AE, 3F908, 3F95F, 3F9B3, 3FA06, 3FA55, 3FAA3, 3FAEE, 3FB37, 3FB7D, 3FBC2, 3FC04, 3FC44, 3FC83, 3FCBF, 3FCFA, 3FD33, 3FD6A, 3FDA0, 3FDD4, 3FE07, 3FE39, 3FE69, 3FE98, 3FEC6, 3FEF3, 3FF20, 3FF4B, 3FF76, 3FFA0, 3FFCA, 3FFF3;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_5ba7f34176997283',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '61d6531e4f596406ac3e102d44aacb43',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_5ba7f34176997283',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFE1, 3FFB8, 3FF8E, 3FF63, 3FF38, 3FF0C, 3FEE0, 3FEB2, 3FE84, 3FE54, 3FE23, 3FDF1, 3FDBD, 3FD88, 3FD52, 3FD1A, 3FCE0, 3FCA4, 3FC67, 3FC28, 3FBE6, 3FBA3, 3FB5D, 3FB16, 3FACC, 3FA80, 3FA31, 3F9E0, 3F98D, 3F937, 3F8DF, 3F884, 3F827, 3F7C7, 3F764, 3F700, 3F698, 3F62E, 3F5C2, 3F553, 3F4E1, 3F46E, 3F3F7, 3F37F, 3F304, 3F287, 3F208, 3F188, 3F105, 3F080, 3EFFA, 3EF72, 3EEE9, 3EE5E, 3EDD2, 3ED45, 3ECB7, 3EC29, 3EB9A, 3EB0B, 3EA7B, 3E9EC, 3E95D, 3E8CE, 3E840, 3E7B3, 3E727, 3E69D, 3E614, 3E58D, 3E509, 3E486, 3E407, 3E38B, 3E312, 3E29C, 3E22B, 3E1BD, 3E155, 3E0F1, 3E093, 3E03A, 3DFE7, 3DF9A, 3DF54, 3DF14, 3DEDC, 3DEAC, 3DE84, 3DE64, 3DE4D, 3DE3F, 3DE3A, 3DE3F, 3DE4E, 3DE68, 3DE8D, 3DEBD, 3DEF9, 3DF41, 3DF95, 3DFF6, 3E064, 3E0E0, 3E169, 3E200, 3E2A6, 3E35B, 3E41F, 3E4F3, 3E5D6, 3E6C9, 3E7CD, 3E8E2, 3EA08, 3EB3F, 3EC87, 3EDE2, 3EF4E, 3F0CD, 3F25F, 3F404, 3F5BB, 3F786, 3F964, 3FB56, 3FD5C, 3FF76;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_439485c3564b1562',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '88485b443437b1e9d0751aaacbc914f3',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_439485c3564b1562',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1A4, 3E7, 63E, 8A9, B29, DBE, 1067, 1326, 15F9, 18E1, 1BDE, 1EF0, 2217, 2553, 28A3, 2C08, 2F82, 3310, 36B3, 3A6A, 3E35, 4214, 4607, 4A0D, 4E27, 5253, 5693, 5AE5, 5F49, 63BF, 6847, 6CE1, 718B, 7645, 7B10, 7FEB, 84D5, 89CE, 8ED5, 93EB, 990E, 9E3E, A37A, A8C2, AE16, B375, B8DE, BE51, C3CD, C951, CEDE, D471, DA0C, DFAC, E552, EAFC, F0AA, F65C, FC10, 101C6, 1077D, 10D35, 112ED, 118A3, 11E58, 1240A, 129B9, 12F64, 1350B, 13AAB, 14046, 145D9, 14B65, 150E9, 15662, 15BD2, 16137, 16691, 16BDE, 1711E, 17650, 17B74, 18088, 1858D, 18A80, 18F62, 19432, 198EF, 19D98, 1A22D, 1A6AD, 1AB17, 1AF6B, 1B3A7, 1B7CD, 1BBDA, 1BFCE, 1C3A9, 1C769, 1CB0F, 1CE9A, 1D20A, 1D55C, 1D893, 1DBAC, 1DEA7, 1E184, 1E442, 1E6E2, 1E961, 1EBC2, 1EE01, 1F021, 1F21F, 1F3FC, 1F5B8, 1F751, 1F8C9, 1FA1F, 1FB52, 1FC62, 1FD50, 1FE1A, 1FEC2, 1FF46, 1FFA7, 1FFE5, 1FFFF;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_475fca4250b91c64',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e319964ce0797d57620aae8a51fc7b37',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_475fca4250b91c64',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFF6, 1FFC9, 1FF79, 1FF06, 1FE70, 1FDB6, 1FCD9, 1FBDA, 1FAB8, 1F973, 1F80C, 1F682, 1F4D7, 1F30A, 1F11C, 1EF0C, 1ECDC, 1EA8C, 1E81B, 1E58B, 1E2DC, 1E00E, 1DD21, 1DA16, 1D6EE, 1D3A9, 1D048, 1CCCA, 1C931, 1C57D, 1C1AF, 1BDC7, 1B9C6, 1B5AD, 1B17B, 1AD32, 1A8D3, 1A45D, 19FD3, 19B33, 19680, 191B9, 18CE0, 187F5, 182F9, 17DEC, 178D0, 173A5, 16E6C, 16925, 163D1, 15E72, 15907, 15392, 14E13, 1488B, 142FC, 13D64, 137C7, 13223, 12C7A, 126CD, 1211C, 11B69, 115B3, 10FFC, 10A45, 1048D, FED7, F921, F36F, EDBF, E812, E26B, DCC8, D72B, D194, CC04, C67C, C0FC, BB84, B617, B0B3, AB5A, A60C, A0CA, 9B94, 966B, 914F, 8C41, 8741, 8250, 7D6E, 789B, 73D9, 6F27, 6A85, 65F5, 6176, 5D09, 58AF, 5466, 5030, 4C0E, 47FE, 4402, 4019, 3C45, 3884, 34D8, 3140, 2DBC, 2A4D, 26F3, 23AD, 207C, 1D60, 1A59, 1767, 148A, 11C1, F0E, C6F, 9E5, 770, 50F, 2C3, 8B;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_99a601efe8925436',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '1ebd69ff4300ceaa2d5f70126851029b',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_99a601efe8925436',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FE67, 3FC58, 3FA5C, 3F874, 3F6A0, 3F4DF, 3F331, 3F196, 3F00E, 3EE99, 3ED36, 3EBE4, 3EAA5, 3E977, 3E85A, 3E74E, 3E653, 3E568, 3E48D, 3E3C1, 3E305, 3E258, 3E1B9, 3E129, 3E0A7, 3E032, 3DFCB, 3DF71, 3DF23, 3DEE1, 3DEAB, 3DE81, 3DE62, 3DE4D, 3DE43, 3DE43, 3DE4D, 3DE5F, 3DE7B, 3DE9F, 3DECC, 3DF00, 3DF3B, 3DF7E, 3DFC8, 3E018, 3E06E, 3E0C9, 3E12B, 3E191, 3E1FC, 3E26B, 3E2DE, 3E356, 3E3D0, 3E44E, 3E4CF, 3E552, 3E5D8, 3E660, 3E6E9, 3E774, 3E801, 3E88E, 3E91C, 3E9AB, 3EA3A, 3EAC9, 3EB59, 3EBE8, 3EC76, 3ED04, 3ED91, 3EE1E, 3EEA9, 3EF33, 3EFBB, 3F042, 3F0C7, 3F14B, 3F1CD, 3F24D, 3F2CA, 3F346, 3F3BF, 3F436, 3F4AB, 3F51E, 3F58E, 3F5FB, 3F666, 3F6CF, 3F735, 3F799, 3F7FA, 3F858, 3F8B4, 3F90D, 3F964, 3F9B9, 3FA0B, 3FA5A, 3FAA8, 3FAF2, 3FB3B, 3FB82, 3FBC6, 3FC08, 3FC48, 3FC87, 3FCC3, 3FCFE, 3FD37, 3FD6E, 3FDA3, 3FDD8, 3FE0A, 3FE3C, 3FE6C, 3FE9B, 3FEC9, 3FEF6, 3FF23, 3FF4E, 3FF79, 3FFA3, 3FFCD, 3FFF6;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_c79031bee1956c0f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '2cfd8376a5e6722faffdad802ebd2cd8',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_c79031bee1956c0f',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFDF, 3FFB5, 3FF8B, 3FF61, 3FF36, 3FF0A, 3FEDD, 3FEAF, 3FE81, 3FE51, 3FE20, 3FDEE, 3FDBA, 3FD85, 3FD4E, 3FD16, 3FCDC, 3FCA1, 3FC63, 3FC24, 3FBE2, 3FB9F, 3FB59, 3FB11, 3FAC7, 3FA7B, 3FA2C, 3F9DB, 3F988, 3F932, 3F8D9, 3F87E, 3F821, 3F7C1, 3F75E, 3F6F9, 3F692, 3F627, 3F5BB, 3F54C, 3F4DA, 3F466, 3F3F0, 3F377, 3F2FD, 3F280, 3F200, 3F17F, 3F0FC, 3F078, 3EFF1, 3EF69, 3EEE0, 3EE55, 3EDC9, 3ED3C, 3ECAF, 3EC20, 3EB91, 3EB02, 3EA72, 3E9E3, 3E954, 3E8C5, 3E837, 3E7AA, 3E71F, 3E694, 3E60C, 3E585, 3E500, 3E47E, 3E3FF, 3E383, 3E30A, 3E295, 3E224, 3E1B7, 3E14E, 3E0EB, 3E08D, 3E034, 3DFE2, 3DF95, 3DF50, 3DF11, 3DED9, 3DEA9, 3DE82, 3DE62, 3DE4C, 3DE3E, 3DE3A, 3DE40, 3DE50, 3DE6A, 3DE90, 3DEC1, 3DEFD, 3DF46, 3DF9B, 3DFFD, 3E06B, 3E0E8, 3E172, 3E20A, 3E2B1, 3E367, 3E42C, 3E500, 3E5E5, 3E6D9, 3E7DE, 3E8F4, 3EA1B, 3EB53, 3EC9C, 3EDF8, 3EF66, 3F0E6, 3F279, 3F41E, 3F5D7, 3F7A3, 3F983, 3FB76, 3FD7D, 3FF99;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_3dbbf781ebfa79a9',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd040022c3f52fa05285e67f9ee6accfd',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_3dbbf781ebfa79a9',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1C8, 40C, 664, 8D1, B52, DE8, 1093, 1352, 1627, 1910, 1C0F, 1F22, 224A, 2587, 28D9, 2C3F, 2FBA, 334A, 36EE, 3AA6, 3E72, 4253, 4646, 4A4E, 4E69, 5297, 56D7, 5B2B, 5F90, 6407, 6890, 6D2B, 71D6, 7692, 7B5E, 8039, 8524, 8A1E, 8F26, 943D, 9960, 9E91, A3CE, A917, AE6C, B3CB, B935, BEA8, C425, C9AA, CF37, D4CB, DA65, E006, E5AC, EB57, F105, F6B7, FC6B, 10222, 107D9, 10D91, 11348, 118FE, 11EB3, 12465, 12A14, 12FBF, 13565, 13B05, 1409F, 14632, 14BBE, 15140, 156BA, 15C29, 1618D, 166E6, 16C32, 17172, 176A3, 17BC6, 180D9, 185DC, 18ACF, 18FB0, 1947E, 1993A, 19DE2, 1A275, 1A6F4, 1AB5D, 1AFAF, 1B3EB, 1B80E, 1BC1A, 1C00C, 1C3E6, 1C7A5, 1CB49, 1CED2, 1D240, 1D591, 1D8C5, 1DBDC, 1DED6, 1E1B1, 1E46D, 1E70B, 1E988, 1EBE6, 1EE24, 1F041, 1F23E, 1F419, 1F5D2, 1F76A, 1F8E0, 1FA33, 1FB64, 1FC72, 1FD5D, 1FE26, 1FECB, 1FF4D, 1FFAC, 1FFE7, 1FFFF;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_54fc69a711c4f922',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '556cba843d7b5c8678e3c8f60f869b23',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_54fc69a711c4f922',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFF4, 1FFC5, 1FF73, 1FEFE, 1FE65, 1FDA9, 1FCCB, 1FBC9, 1FAA4, 1F95D, 1F7F4, 1F668, 1F4BB, 1F2EC, 1F0FC, 1EEEA, 1ECB8, 1EA66, 1E7F3, 1E561, 1E2B0, 1DFE0, 1DCF1, 1D9E5, 1D6BB, 1D374, 1D011, 1CC91, 1C8F7, 1C541, 1C171, 1BD88, 1B985, 1B56A, 1B137, 1ACED, 1A88C, 1A415, 19F89, 19AE9, 19634, 1916C, 18C92, 187A6, 182A9, 17D9B, 1787E, 17352, 16E17, 168D0, 1637C, 15E1B, 158B0, 1533A, 14DBB, 14833, 142A2, 13D0B, 1376D, 131C9, 12C20, 12672, 120C1, 11B0E, 11558, 10FA1, 109E9, 10432, FE7B, F8C6, F313, ED64, E7B8, E210, DC6E, D6D1, D13A, CBAB, C623, C0A4, BB2D, B5C0, B05D, AB05, A5B8, A076, 9B41, 9619, 90FE, 8BF0, 86F1, 8201, 7D20, 784F, 738D, 6EDC, 6A3C, 65AD, 612F, 5CC3, 5869, 5422, 4FEE, 4BCC, 47BE, 43C3, 3FDC, 3C08, 3849, 349E, 3107, 2D85, 2A17, 26BE, 2379, 204A, 1D2F, 1A29, 1738, 145C, 1195, EE3, C46, 9BD, 749, 4EA, 29F, 68;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_d0c0a2708157043e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '6de25f7abb4066a92538286bed9bc901',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_d0c0a2708157043e',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FE46, 3FC37, 3FA3D, 3F856, 3F683, 3F4C3, 3F317, 3F17D, 3EFF7, 3EE82, 3ED20, 3EBD0, 3EA92, 3E965, 3E849, 3E73E, 3E644, 3E559, 3E47F, 3E3B5, 3E2FA, 3E24D, 3E1B0, 3E121, 3E09F, 3E02B, 3DFC5, 3DF6B, 3DF1E, 3DEDD, 3DEA8, 3DE7F, 3DE60, 3DE4C, 3DE43, 3DE43, 3DE4D, 3DE61, 3DE7D, 3DEA2, 3DECF, 3DF03, 3DF3F, 3DF83, 3DFCD, 3E01D, 3E073, 3E0CF, 3E131, 3E197, 3E202, 3E272, 3E2E6, 3E35D, 3E3D8, 3E456, 3E4D7, 3E55A, 3E5E0, 3E668, 3E6F2, 3E77D, 3E809, 3E897, 3E925, 3E9B4, 3EA43, 3EAD2, 3EB62, 3EBF1, 3EC7F, 3ED0D, 3ED9A, 3EE26, 3EEB1, 3EF3B, 3EFC4, 3F04B, 3F0D0, 3F153, 3F1D5, 3F255, 3F2D2, 3F34E, 3F3C7, 3F43E, 3F4B3, 3F525, 3F595, 3F602, 3F66D, 3F6D5, 3F73B, 3F79F, 3F800, 3F85E, 3F8BA, 3F913, 3F96A, 3F9BE, 3FA10, 3FA5F, 3FAAC, 3FAF7, 3FB40, 3FB86, 3FBCA, 3FC0C, 3FC4C, 3FC8B, 3FCC7, 3FD01, 3FD3A, 3FD71, 3FDA7, 3FDDB, 3FE0D, 3FE3F, 3FE6F, 3FE9E, 3FECC, 3FEF9, 3FF25, 3FF51, 3FF7B, 3FFA5, 3FFCF, 3FFF8;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_46a48dd8487a8048',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f1f7a7d9905c0f50d29ff3ce16438ea0',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_46a48dd8487a8048',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFDC, 3FFB3, 3FF89, 3FF5E, 3FF33, 3FF07, 3FEDA, 3FEAC, 3FE7E, 3FE4E, 3FE1D, 3FDEA, 3FDB7, 3FD82, 3FD4B, 3FD13, 3FCD9, 3FC9D, 3FC5F, 3FC20, 3FBDE, 3FB9A, 3FB55, 3FB0D, 3FAC2, 3FA76, 3FA27, 3F9D6, 3F982, 3F92C, 3F8D4, 3F878, 3F81B, 3F7BB, 3F758, 3F6F3, 3F68B, 3F621, 3F5B4, 3F545, 3F4D3, 3F45F, 3F3E8, 3F370, 3F2F5, 3F278, 3F1F8, 3F177, 3F0F4, 3F06F, 3EFE9, 3EF61, 3EED7, 3EE4C, 3EDC0, 3ED33, 3ECA6, 3EC17, 3EB88, 3EAF9, 3EA69, 3E9DA, 3E94B, 3E8BC, 3E82E, 3E7A2, 3E716, 3E68C, 3E603, 3E57C, 3E4F8, 3E476, 3E3F7, 3E37B, 3E303, 3E28E, 3E21D, 3E1B0, 3E148, 3E0E5, 3E087, 3E02F, 3DFDD, 3DF91, 3DF4B, 3DF0D, 3DED6, 3DEA7, 3DE7F, 3DE61, 3DE4A, 3DE3D, 3DE3A, 3DE40, 3DE51, 3DE6C, 3DE93, 3DEC4, 3DF01, 3DF4B, 3DFA1, 3E003, 3E073, 3E0F0, 3E17B, 3E214, 3E2BC, 3E373, 3E439, 3E50E, 3E5F3, 3E6E9, 3E7EF, 3E906, 3EA2E, 3EB67, 3ECB2, 3EE0E, 3EF7D, 3F0FF, 3F293, 3F439, 3F5F3, 3F7C1, 3F9A2, 3FB96, 3FD9F, 3FFBB;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_248a4d998427e189',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '9eac7f2200e6d4d751defc7837e5ced4',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_248a4d998427e189',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1EC, 431, 68A, 8F8, B7B, E12, 10BE, 137F, 1655, 1940, 1C3F, 1F54, 227D, 25BB, 290F, 2C76, 2FF3, 3383, 3729, 3AE2, 3EB0, 4291, 4686, 4A8F, 4EAB, 52DA, 571C, 5B70, 5FD7, 644F, 68DA, 6D75, 7221, 76DE, 7BAB, 8087, 8573, 8A6E, 8F77, 948E, 99B3, 9EE4, A422, A96C, AEC2, B422, B98C, BF00, C47D, CA02, CF90, D524, DABF, E060, E607, EBB1, F160, F712, FCC7, 1027D, 10834, 10DEC, 113A4, 1195A, 11F0E, 124C0, 12A6F, 13019, 135BF, 13B5F, 140F9, 1468B, 14C16, 15198, 15711, 15C80, 161E3, 1673B, 16C87, 171C5, 176F6, 17C17, 1812A, 1862C, 18B1D, 18FFD, 194CA, 19985, 19E2C, 1A2BE, 1A73B, 1ABA2, 1AFF3, 1B42D, 1B850, 1BC5A, 1C04B, 1C422, 1C7E0, 1CB82, 1CF0A, 1D275, 1D5C5, 1D8F7, 1DC0D, 1DF04, 1E1DD, 1E498, 1E733, 1E9AF, 1EC0B, 1EE47, 1F062, 1F25C, 1F435, 1F5ED, 1F782, 1F8F6, 1FA47, 1FB76, 1FC82, 1FD6B, 1FE31, 1FED4, 1FF54, 1FFB1, 1FFEA, 1FFFF;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_7ada992c63af1168',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '62cb3f8dd9229d5c415a720c50192907',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_7ada992c63af1168',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFF2, 1FFC1, 1FF6D, 1FEF5, 1FE5A, 1FD9C, 1FCBB, 1FBB8, 1FA91, 1F948, 1F7DC, 1F64F, 1F49F, 1F2CE, 1F0DC, 1EEC8, 1EC94, 1EA40, 1E7CB, 1E537, 1E284, 1DFB2, 1DCC1, 1D9B3, 1D687, 1D33E, 1CFD9, 1CC58, 1C8BC, 1C505, 1C133, 1BD48, 1B944, 1B528, 1B0F3, 1ACA8, 1A845, 1A3CD, 19F40, 19A9E, 195E8, 1911F, 18C44, 18757, 18258, 17D4A, 1782C, 172FF, 16DC3, 1687B, 16326, 15DC5, 15859, 152E3, 14D63, 147DA, 14249, 13CB1, 13713, 1316E, 12BC5, 12617, 12066, 11AB2, 114FC, 10F45, 1098E, 103D6, FE20, F86B, F2B8, ED09, E75D, E1B6, DC14, D677, D0E1, CB52, C5CB, C04C, BAD6, B56A, B007, AAB0, A563, A022, 9AEE, 95C7, 90AC, 8BA0, 86A2, 81B3, 7CD3, 7802, 7342, 6E92, 69F2, 6564, 60E8, 5C7D, 5824, 53DE, 4FAB, 4B8B, 477D, 4384, 3F9E, 3BCC, 380E, 3464, 30CE, 2D4D, 29E1, 2689, 2346, 2017, 1CFE, 19FA, 170A, 142F, 116A, EB9, C1D, 995, 722, 4C4, 27B, 45;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_91d7ea8fa9b078a5',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '649ed080a705609304e5a565c8a0a62e',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_91d7ea8fa9b078a5',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FE24, 3FC17, 3FA1E, 3F838, 3F667, 3F4A8, 3F2FD, 3F164, 3EFDF, 3EE6C, 3ED0B, 3EBBC, 3EA7E, 3E952, 3E838, 3E72E, 3E634, 3E54B, 3E472, 3E3A9, 3E2EE, 3E243, 3E1A6, 3E118, 3E098, 3E025, 3DFBF, 3DF66, 3DF1A, 3DEDA, 3DEA5, 3DE7D, 3DE5F, 3DE4B, 3DE43, 3DE44, 3DE4E, 3DE62, 3DE7F, 3DEA4, 3DED2, 3DF07, 3DF43, 3DF87, 3DFD1, 3E022, 3E079, 3E0D5, 3E137, 3E19E, 3E209, 3E279, 3E2ED, 3E365, 3E3E0, 3E45E, 3E4DF, 3E563, 3E5E9, 3E671, 3E6FA, 3E786, 3E812, 3E8A0, 3E92E, 3E9BD, 3EA4C, 3EADB, 3EB6B, 3EBFA, 3EC88, 3ED16, 3EDA3, 3EE2F, 3EEBA, 3EF44, 3EFCC, 3F053, 3F0D8, 3F15B, 3F1DD, 3F25C, 3F2DA, 3F355, 3F3CE, 3F445, 3F4BA, 3F52C, 3F59C, 3F609, 3F674, 3F6DC, 3F742, 3F7A5, 3F805, 3F864, 3F8BF, 3F918, 3F96F, 3F9C3, 3FA15, 3FA64, 3FAB1, 3FAFC, 3FB44, 3FB8A, 3FBCE, 3FC10, 3FC50, 3FC8E, 3FCCB, 3FD05, 3FD3E, 3FD75, 3FDAA, 3FDDE, 3FE11, 3FE42, 3FE72, 3FEA1, 3FECF, 3FEFC, 3FF28, 3FF53, 3FF7E, 3FFA8, 3FFD2, 3FFFB;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_e0eeb82ca1b47080',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '718709881a9f109e71a6e21d1a9337c2',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_e0eeb82ca1b47080',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFD9, 3FFB0, 3FF86, 3FF5B, 3FF30, 3FF04, 3FED7, 3FEAA, 3FE7B, 3FE4B, 3FE1A, 3FDE7, 3FDB4, 3FD7E, 3FD47, 3FD0F, 3FCD5, 3FC99, 3FC5B, 3FC1C, 3FBDA, 3FB96, 3FB50, 3FB08, 3FABE, 3FA71, 3FA22, 3F9D1, 3F97D, 3F927, 3F8CE, 3F873, 3F815, 3F7B5, 3F752, 3F6EC, 3F684, 3F61A, 3F5AD, 3F53E, 3F4CC, 3F458, 3F3E1, 3F368, 3F2ED, 3F270, 3F1F0, 3F16F, 3F0EC, 3F067, 3EFE0, 3EF58, 3EECF, 3EE44, 3EDB8, 3ED2B, 3EC9D, 3EC0E, 3EB7F, 3EAF0, 3EA60, 3E9D1, 3E942, 3E8B3, 3E826, 3E799, 3E70D, 3E683, 3E5FB, 3E574, 3E4F0, 3E46E, 3E3EF, 3E374, 3E2FB, 3E287, 3E216, 3E1AA, 3E142, 3E0DF, 3E082, 3E02A, 3DFD8, 3DF8C, 3DF47, 3DF09, 3DED3, 3DEA4, 3DE7D, 3DE5F, 3DE49, 3DE3D, 3DE3A, 3DE41, 3DE52, 3DE6E, 3DE95, 3DEC8, 3DF06, 3DF50, 3DFA6, 3E00A, 3E07A, 3E0F8, 3E184, 3E21E, 3E2C7, 3E37F, 3E446, 3E51C, 3E602, 3E6F9, 3E800, 3E918, 3EA41, 3EB7B, 3ECC7, 3EE25, 3EF95, 3F117, 3F2AC, 3F454, 3F610, 3F7DE, 3F9C0, 3FBB6, 3FDC0, 3FFDD;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_05e25360641c7d19',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c2b31ff8cb45cf80dbc288d61f2af74a',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_05e25360641c7d19',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 20F, 456, 6B0, 920, BA3, E3C, 10E9, 13AC, 1683, 196F, 1C70, 1F86, 22B1, 25F0, 2944, 2CAD, 302B, 33BD, 3764, 3B1E, 3EED, 42D0, 46C6, 4AD0, 4EED, 531E, 5761, 5BB6, 601E, 6498, 6923, 6DBF, 726C, 772A, 7BF8, 80D6, 85C3, 8ABE, 8FC8, 94E0, 9A06, 9F38, A477, A9C1, AF17, B478, B9E3, BF57, C4D5, CA5B, CFE9, D57E, DB19, E0BB, E661, EC0C, F1BB, F76D, FD22, 102D8, 10890, 10E48, 113FF, 119B5, 11F69, 1251B, 12ACA, 13074, 13619, 13BB9, 14152, 146E4, 14C6F, 151F0, 15768, 15CD6, 16239, 16790, 16CDB, 17219, 17748, 17C69, 1817A, 1867C, 18B6C, 1904A, 19517, 199D0, 19E75, 1A306, 1A782, 1ABE8, 1B038, 1B470, 1B891, 1BC99, 1C089, 1C45F, 1C81B, 1CBBC, 1CF41, 1D2AB, 1D5F9, 1D92A, 1DC3D, 1DF33, 1E20A, 1E4C3, 1E75C, 1E9D6, 1EC30, 1EE6A, 1F083, 1F27B, 1F452, 1F607, 1F79A, 1F90C, 1FA5B, 1FB87, 1FC91, 1FD78, 1FE3C, 1FEDD, 1FF5B, 1FFB5, 1FFEC, 1FFFF;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_6c46d81cd65d17dd',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '82149841359e63a2baa7997be456a13a',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_6c46d81cd65d17dd',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFF0, 1FFBD, 1FF66, 1FEED, 1FE50, 1FD8F, 1FCAC, 1FBA6, 1FA7D, 1F932, 1F7C4, 1F635, 1F483, 1F2B0, 1F0BB, 1EEA6, 1EC70, 1EA19, 1E7A3, 1E50D, 1E257, 1DF83, 1DC91, 1D981, 1D653, 1D309, 1CFA2, 1CC1F, 1C881, 1C4C9, 1C0F6, 1BD09, 1B903, 1B4E5, 1B0AF, 1AC62, 1A7FE, 1A385, 19EF6, 19A53, 1959C, 190D2, 18BF5, 18707, 18208, 17CF8, 177D9, 172AB, 16D6F, 16826, 162D0, 15D6E, 15802, 1528B, 14D0A, 14781, 141F0, 13C57, 136B8, 13114, 12B6A, 125BC, 1200B, 11A57, 114A1, 10EEA, 10932, 1037B, FDC4, F810, F25D, ECAE, E703, E15C, DBBA, D61E, D088, CAFA, C573, BFF4, BA7F, B513, AFB1, AA5A, A50F, 9FCF, 9A9B, 9575, 905B, 8B50, 8653, 8164, 7C85, 77B6, 72F6, 6E47, 69A9, 651C, 60A1, 5C37, 57E0, 539B, 4F68, 4B49, 473D, 4345, 3F60, 3B8F, 37D2, 342A, 3095, 2D16, 29AA, 2654, 2312, 1FE5, 1CCD, 19CA, 16DC, 1402, 113E, E8E, BF3, 96D, 6FC, 49F, 257, 23;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_aa94eba4bc322ca8',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'df2c7ad953095bb5f955465272d40af2',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_aa94eba4bc322ca8',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FE03, 3FBF7, 3F9FF, 3F81B, 3F64A, 3F48D, 3F2E3, 3F14C, 3EFC7, 3EE55, 3ECF5, 3EBA7, 3EA6B, 3E940, 3E827, 3E71E, 3E625, 3E53D, 3E465, 3E39D, 3E2E3, 3E239, 3E19D, 3E110, 3E090, 3E01E, 3DFB9, 3DF61, 3DF16, 3DED6, 3DEA3, 3DE7A, 3DE5D, 3DE4B, 3DE42, 3DE44, 3DE4F, 3DE64, 3DE81, 3DEA7, 3DED5, 3DF0A, 3DF47, 3DF8C, 3DFD6, 3E027, 3E07F, 3E0DB, 3E13D, 3E1A4, 3E210, 3E280, 3E2F4, 3E36C, 3E3E8, 3E466, 3E4E7, 3E56B, 3E5F1, 3E679, 3E703, 3E78E, 3E81B, 3E8A9, 3E937, 3E9C6, 3EA55, 3EAE4, 3EB74, 3EC02, 3EC91, 3ED1F, 3EDAC, 3EE38, 3EEC3, 3EF4C, 3EFD5, 3F05B, 3F0E0, 3F164, 3F1E5, 3F264, 3F2E2, 3F35D, 3F3D6, 3F44D, 3F4C1, 3F533, 3F5A3, 3F610, 3F67A, 3F6E2, 3F748, 3F7AB, 3F80B, 3F869, 3F8C5, 3F91E, 3F974, 3F9C8, 3FA1A, 3FA69, 3FAB6, 3FB00, 3FB49, 3FB8F, 3FBD3, 3FC14, 3FC54, 3FC92, 3FCCE, 3FD08, 3FD41, 3FD78, 3FDAD, 3FDE1, 3FE14, 3FE45, 3FE75, 3FEA4, 3FED2, 3FEFF, 3FF2B, 3FF56, 3FF81, 3FFAB, 3FFD4, 3FFFD;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_44865b1771e00ff3',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '25e4e651e149c0da833ce6928031e6b5',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_44865b1771e00ff3',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '4e2e7526ca6ba000c340019688a5c4b5',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 3FFD7, 3FFAD, 3FF83, 3FF59, 3FF2D, 3FF01, 3FED4, 3FEA7, 3FE78, 3FE48, 3FE17, 3FDE4, 3FDB0, 3FD7B, 3FD44, 3FD0B, 3FCD1, 3FC95, 3FC57, 3FC18, 3FBD6, 3FB92, 3FB4C, 3FB04, 3FAB9, 3FA6C, 3FA1D, 3F9CC, 3F978, 3F921, 3F8C8, 3F86D, 3F80F, 3F7AF, 3F74B, 3F6E6, 3F67E, 3F613, 3F5A6, 3F537, 3F4C5, 3F450, 3F3D9, 3F360, 3F2E5, 3F268, 3F1E8, 3F167, 3F0E4, 3F05F, 3EFD8, 3EF50, 3EEC6, 3EE3B, 3EDAF, 3ED22, 3EC94, 3EC05, 3EB76, 3EAE7, 3EA57, 3E9C8, 3E939, 3E8AB, 3E81D, 3E790, 3E705, 3E67A, 3E5F2, 3E56C, 3E4E8, 3E466, 3E3E8, 3E36C, 3E2F4, 3E27F, 3E20F, 3E1A3, 3E13B, 3E0D9, 3E07C, 3E024, 3DFD3, 3DF88, 3DF43, 3DF06, 3DED0, 3DEA1, 3DE7B, 3DE5D, 3DE48, 3DE3D, 3DE3A, 3DE42, 3DE54, 3DE71, 3DE98, 3DECB, 3DF0A, 3DF55, 3DFAC, 3E010, 3E082, 3E101, 3E18D, 3E229, 3E2D2, 3E38B, 3E453, 3E52A, 3E611, 3E709, 3E811, 3E92A, 3EA54, 3EB8F, 3ECDC, 3EE3B, 3EFAC, 3F130, 3F2C6, 3F470, 3F62C, 3F7FC, 3F9DF, 3FBD6, 3FDE1;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_c81eb45d03d0fafa',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '183656731f05cabcbf6be7481492dfe8',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_c81eb45d03d0fafa',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 233, 47B, 6D7, 947, BCC, E66, 1115, 13D9, 16B1, 199E, 1CA1, 1FB8, 22E4, 2625, 297A, 2CE5, 3064, 33F7, 379F, 3B5B, 3F2B, 430F, 4706, 4B12, 4F30, 5361, 57A6, 5BFC, 6065, 64E0, 696C, 6E0A, 72B8, 7777, 7C46, 8124, 8612, 8B0E, 9019, 9532, 9A58, 9F8C, A4CB, AA16, AF6D, B4CE, BA3A, BFAF, C52D, CAB4, D042, D5D7, DB73, E115, E6BC, EC67, F216, F7C9, FD7D, 10334, 108EB, 10EA3, 1145A, 11A10, 11FC5, 12576, 12B24, 130CE, 13673, 13C13, 141AB, 1473D, 14CC7, 15248, 157BF, 15D2D, 1628F, 167E5, 16D2F, 1726C, 1779B, 17CBB, 181CB, 186CB, 18BBA, 19098, 19563, 19A1B, 19EBF, 1A34F, 1A7C9, 1AC2E, 1B07C, 1B4B3, 1B8D2, 1BCD9, 1C0C7, 1C49B, 1C855, 1CBF5, 1CF79, 1D2E1, 1D62D, 1D95C, 1DC6D, 1DF61, 1E236, 1E4ED, 1E785, 1E9FC, 1EC55, 1EE8C, 1F0A3, 1F299, 1F46E, 1F621, 1F7B3, 1F922, 1FA6F, 1FB99, 1FCA1, 1FD86, 1FE47, 1FEE6, 1FF62, 1FFBA, 1FFEF;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_54d136daa81ebfe6',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '7b8fa839f37f187116ca16b74dfea12b',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_54d136daa81ebfe6',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFF, 1FFEE, 1FFB9, 1FF60, 1FEE4, 1FE45, 1FD82, 1FC9D, 1FB95, 1FA6A, 1F91C, 1F7AC, 1F61B, 1F467, 1F292, 1F09B, 1EE83, 1EC4B, 1E9F3, 1E77A, 1E4E2, 1E22B, 1DF55, 1DC61, 1D94F, 1D620, 1D2D3, 1CF6B, 1CBE6, 1C847, 1C48C, 1C0B7, 1BCC9, 1B8C2, 1B4A2, 1B06B, 1AC1D, 1A7B8, 1A33D, 19EAD, 19A08, 19550, 19085, 18BA7, 186B8, 181B7, 17CA7, 17787, 17258, 16D1B, 167D1, 1627A, 15D18, 157AB, 15233, 14CB2, 14728, 14197, 13BFE, 1365E, 130B9, 12B0F, 12561, 11FB0, 119FC, 11446, 10E8E, 108D7, 1031F, FD69, F7B4, F202, EC53, E6A8, E101, DB60, D5C4, D02F, CAA1, C51B, BF9D, BA28, B4BD, AF5C, AA05, A4BA, 9F7B, 9A48, 9523, 900A, 8AFF, 8603, 8116, 7C38, 7769, 72AB, 6DFD, 6960, 64D4, 6059, 5BF1, 579B, 5357, 4F26, 4B08, 46FD, 4306, 3F22, 3B53, 3797, 33F0, 305D, 2CDE, 2974, 261F, 22DF, 1FB3, 1C9C, 199B, 16AE, 13D6, 1112, E64, BCB, 946, 6D6, 47A, 233;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_291d894de2e86bc1',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a124842c35e4b9bdd18a0a29d91ba2c3',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_291d894de2e86bc1',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 3FDE1, 3FBD7, 3F9E0, 3F7FD, 3F62E, 3F472, 3F2C9, 3F133, 3EFAF, 3EE3E, 3ECE0, 3EB93, 3EA58, 3E92E, 3E816, 3E70E, 3E616, 3E52F, 3E458, 3E391, 3E2D8, 3E22F, 3E194, 3E107, 3E088, 3E017, 3DFB3, 3DF5C, 3DF11, 3DED3, 3DEA0, 3DE78, 3DE5C, 3DE4A, 3DE42, 3DE45, 3DE50, 3DE65, 3DE83, 3DEAA, 3DED8, 3DF0E, 3DF4C, 3DF90, 3DFDB, 3E02D, 3E084, 3E0E1, 3E144, 3E1AB, 3E217, 3E287, 3E2FC, 3E374, 3E3EF, 3E46E, 3E4EF, 3E573, 3E5FA, 3E682, 3E70C, 3E797, 3E824, 3E8B1, 3E940, 3E9CF, 3EA5E, 3EAED, 3EB7C, 3EC0B, 3EC9A, 3ED28, 3EDB5, 3EE41, 3EECB, 3EF55, 3EFDD, 3F064, 3F0E9, 3F16C, 3F1ED, 3F26C, 3F2E9, 3F364, 3F3DD, 3F454, 3F4C8, 3F53A, 3F5A9, 3F616, 3F681, 3F6E9, 3F74E, 3F7B1, 3F811, 3F86F, 3F8CA, 3F923, 3F97A, 3F9CD, 3FA1F, 3FA6E, 3FABA, 3FB05, 3FB4D, 3FB93, 3FBD7, 3FC18, 3FC58, 3FC96, 3FCD2, 3FD0C, 3FD45, 3FD7B, 3FDB1, 3FDE4, 3FE17, 3FE48, 3FE78, 3FEA7, 3FED5, 3FF01, 3FF2D, 3FF59, 3FF83, 3FFAD, 3FFD7;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_888977e97379400d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '83dcdefeee861dc7175f42fa1e629b6a',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_888977e97379400d',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd79079c104728231229f8185fe35b4f8',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00000001";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((8 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_b437b02512',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6881e3e9fe47f0cbdc2e654a4e3326e1',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((8 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_91ef1678ca',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '3357ffe50653e9d14d4f9101dfc712bf',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "10000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((8 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_e8aae5d3bb',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Binary_Counter virtex6 Xilinx,_Inc. 11.0',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = DOWN',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = true',
    'CSET output_width = 8',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_b7550dc611e0410a',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '0611698a9c0adacc815bfeaa83a316b9',
    'sourceFile' => 'hdl/xlcounter_free.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      clk: in std_logic;
      ce: in std_logic;
      SINIT: in std_logic;
      load: in std_logic;
      l: in std_logic_vector(op_width - 1 downto 0);
      q: out std_logic_vector(op_width - 1 downto 0)',
      'core_instance_text' => '        clk => clk,
        ce => core_ce,
        SINIT => core_sinit,
        load => load(0),
        l => din,
        q => op_net',
      'core_name0' => 'cntr_11_0_b7550dc611e0410a',
      'entityName' => 'xlcounter_free_pfb4t11_bb',
      'entity_name.0' => 'xlcounter_free',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '79cfaf8c15ce6d93b744ee6a4a4e8394',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal d0_1_24: std_logic;
  signal d1_1_27: std_logic;
  signal fully_2_1_bit: std_logic;
begin
  d0_1_24 <= d0(0);
  d1_1_27 <= d1(0);
  fully_2_1_bit <= d0_1_24 or d1_1_27;
  y <= std_logic_to_vector(fully_2_1_bit);
end',
      'crippled_entity' => 'is
  port (
    d0 : in std_logic_vector((1 - 1) downto 0);
    d1 : in std_logic_vector((1 - 1) downto 0);
    y : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'logical_aacf6e1b0e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '4cbc8f55ab0bdad8c93c57462ba138dc',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal sel_1_20: std_logic_vector((1 - 1) downto 0);
  signal d0_1_24: std_logic;
  signal d1_1_27: std_logic;
  signal unregy_join_6_1: std_logic;
begin
  sel_1_20 <= sel;
  d0_1_24 <= d0(0);
  d1_1_27 <= d1(0);
  proc_switch_6_1: process (d0_1_24, d1_1_27, sel_1_20)
  is
  begin
    case sel_1_20 is 
      when "0" =>
        unregy_join_6_1 <= d0_1_24;
      when others =>
        unregy_join_6_1 <= d1_1_27;
    end case;
  end process proc_switch_6_1;
  y <= std_logic_to_vector(unregy_join_6_1);
end',
      'crippled_entity' => 'is
  port (
    sel : in std_logic_vector((1 - 1) downto 0);
    d0 : in std_logic_vector((1 - 1) downto 0);
    d1 : in std_logic_vector((1 - 1) downto 0);
    y : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'mux_1bef4ba0e4',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a40234a17f28f2875a29b26c0a65bcc1',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_1_31: unsigned((8 - 1) downto 0);
  signal b_1_34: unsigned((8 - 1) downto 0);
  signal result_12_3_rel: boolean;
begin
  a_1_31 <= std_logic_vector_to_unsigned(a);
  b_1_34 <= std_logic_vector_to_unsigned(b);
  result_12_3_rel <= a_1_31 = b_1_34;
  op <= boolean_to_vector(result_12_3_rel);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((8 - 1) downto 0);
    b : in std_logic_vector((8 - 1) downto 0);
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'relational_54048c8b02',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f656afd1eff99591face4c094ec46614',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_1_31: unsigned((8 - 1) downto 0);
  signal b_1_34: unsigned((8 - 1) downto 0);
  signal result_14_3_rel: boolean;
begin
  a_1_31 <= std_logic_vector_to_unsigned(a);
  b_1_34 <= std_logic_vector_to_unsigned(b);
  result_14_3_rel <= a_1_31 /= b_1_34;
  op <= boolean_to_vector(result_14_3_rel);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((8 - 1) downto 0);
    b : in std_logic_vector((8 - 1) downto 0);
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'relational_16235eb2bf',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a1f471f7cac3edb1760dc8f584e95df7',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFFD, 3FFD4, 3FFAB, 3FF81, 3FF56, 3FF2B, 3FEFF, 3FED2, 3FEA4, 3FE75, 3FE45, 3FE13, 3FDE1, 3FDAD, 3FD78, 3FD41, 3FD08, 3FCCE, 3FC91, 3FC53, 3FC13, 3FBD2, 3FB8E, 3FB47, 3FAFF, 3FAB4, 3FA67, 3FA18, 3F9C6, 3F972, 3F91C, 3F8C3, 3F867, 3F809, 3F7A8, 3F745, 3F6DF, 3F677, 3F60C, 3F59F, 3F530, 3F4BD, 3F449, 3F3D2, 3F359, 3F2DD, 3F260, 3F1E0, 3F15F, 3F0DB, 3F056, 3EFCF, 3EF47, 3EEBD, 3EE32, 3EDA6, 3ED19, 3EC8B, 3EBFC, 3EB6D, 3EADE, 3EA4E, 3E9BF, 3E930, 3E8A2, 3E814, 3E787, 3E6FC, 3E672, 3E5EA, 3E563, 3E4E0, 3E45E, 3E3E0, 3E364, 3E2EC, 3E278, 3E208, 3E19C, 3E135, 3E0D3, 3E076, 3E01F, 3DFCE, 3DF83, 3DF3F, 3DF02, 3DECD, 3DE9F, 3DE79, 3DE5C, 3DE47, 3DE3C, 3DE3A, 3DE43, 3DE55, 3DE73, 3DE9B, 3DECF, 3DF0E, 3DF5A, 3DFB2, 3E017, 3E089, 3E109, 3E197, 3E233, 3E2DD, 3E397, 3E460, 3E538, 3E620, 3E719, 3E822, 3E93C, 3EA67, 3EBA3, 3ECF2, 3EE52, 3EFC4, 3F149, 3F2E0, 3F48B, 3F648, 3F819, 3F9FE, 3FBF6, 3FE02;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_421a70b2746a9018',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a4c2f10fab6343005612539db5f8d274',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_421a70b2746a9018',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 23, 257, 4A0, 6FD, 96F, BF5, E91, 1141, 1406, 16DF, 19CE, 1CD2, 1FEA, 2317, 2659, 29B0, 2D1C, 309C, 3431, 37DA, 3B97, 3F68, 434E, 4747, 4B53, 4F72, 53A5, 57EA, 5C42, 60AC, 6528, 69B5, 6E54, 7303, 77C3, 7C93, 8173, 8661, 8B5F, 906B, 9584, 9AAB, 9FDF, A51F, AA6B, AFC3, B525, BA91, C007, C585, CB0C, D09B, D631, DBCD, E16F, E716, ECC2, F271, F824, FDD9, 1038F, 10947, 10EFF, 114B6, 11A6C, 12020, 125D1, 12B7F, 13129, 136CD, 13C6C, 14205, 14796, 14D1F, 152A0, 15817, 15D83, 162E5, 1683A, 16D84, 172BF, 177ED, 17D0C, 1821B, 1871B, 18C09, 190E5, 195AF, 19A66, 19F09, 1A397, 1A810, 1AC73, 1B0C0, 1B4F6, 1B913, 1BD19, 1C105, 1C4D8, 1C890, 1CC2E, 1CFB0, 1D316, 1D661, 1D98E, 1DC9D, 1DF8F, 1E263, 1E517, 1E7AD, 1EA23, 1EC79, 1EEAF, 1F0C4, 1F2B8, 1F48A, 1F63B, 1F7CB, 1F938, 1FA82, 1FBAB, 1FCB0, 1FD93, 1FE52, 1FEEF, 1FF68, 1FFBE, 1FFF1;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_ca1e7449ecaa3908',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '713f75a50623ee273348ced882033d91',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_ca1e7449ecaa3908',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFF, 1FFEC, 1FFB4, 1FF59, 1FEDB, 1FE3A, 1FD75, 1FC8D, 1FB83, 1FA56, 1F906, 1F794, 1F600, 1F44A, 1F273, 1F07A, 1EE61, 1EC27, 1E9CC, 1E752, 1E4B8, 1E1FF, 1DF27, 1DC31, 1D91D, 1D5EC, 1D29E, 1CF33, 1CBAD, 1C80C, 1C450, 1C079, 1BC8A, 1B881, 1B460, 1B027, 1ABD7, 1A770, 1A2F4, 19E63, 199BD, 19504, 19037, 18B59, 18668, 18167, 17C55, 17734, 17204, 16CC7, 1677C, 16225, 15CC1, 15753, 151DB, 14C5A, 146CF, 1413D, 13BA4, 13604, 1305F, 12AB5, 12506, 11F55, 119A0, 113EA, 10E33, 1087B, 102C4, FD0E, F759, F1A7, EBF8, E64D, E0A7, DB06, D56B, CFD6, CA48, C4C3, BF45, B9D1, B466, AF06, A9B0, A466, 9F28, 99F6, 94D1, 8FB9, 8AAF, 85B4, 80C7, 7BEA, 771D, 725F, 6DB2, 6916, 648C, 6012, 5BAB, 5756, 5313, 4EE3, 4AC7, 46BD, 42C7, 3EE5, 3B16, 375C, 33B6, 3024, 2CA7, 293F, 25EB, 22AB, 1F81, 1C6C, 196B, 167F, 13A9, 10E7, E3A, BA2, 91E, 6AF, 455, 20F;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_52940ea787a013a2',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c0927366836cd78afdf05a284e9db992',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_52940ea787a013a2',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFDD, 3FDC0, 3FBB7, 3F9C1, 3F7E0, 3F611, 3F457, 3F2AF, 3F11A, 3EF98, 3EE28, 3ECCA, 3EB7F, 3EA45, 3E91C, 3E805, 3E6FE, 3E608, 3E521, 3E44B, 3E385, 3E2CD, 3E225, 3E18B, 3E0FF, 3E081, 3E011, 3DFAD, 3DF57, 3DF0D, 3DECF, 3DE9D, 3DE76, 3DE5A, 3DE49, 3DE42, 3DE45, 3DE51, 3DE67, 3DE85, 3DEAC, 3DEDB, 3DF12, 3DF50, 3DF95, 3DFE0, 3E032, 3E08A, 3E0E7, 3E14A, 3E1B2, 3E21E, 3E28F, 3E303, 3E37C, 3E3F7, 3E476, 3E4F8, 3E57C, 3E602, 3E68A, 3E714, 3E7A0, 3E82D, 3E8BA, 3E949, 3E9D8, 3EA67, 3EAF6, 3EB85, 3EC14, 3ECA3, 3ED30, 3EDBD, 3EE49, 3EED4, 3EF5D, 3EFE6, 3F06C, 3F0F1, 3F174, 3F1F5, 3F274, 3F2F1, 3F36C, 3F3E5, 3F45B, 3F4CF, 3F541, 3F5B0, 3F61D, 3F687, 3F6EF, 3F754, 3F7B7, 3F817, 3F875, 3F8D0, 3F929, 3F97F, 3F9D3, 3FA24, 3FA73, 3FABF, 3FB09, 3FB51, 3FB97, 3FBDB, 3FC1D, 3FC5C, 3FC9A, 3FCD6, 3FD10, 3FD48, 3FD7F, 3FDB4, 3FDE8, 3FE1A, 3FE4B, 3FE7B, 3FEAA, 3FED7, 3FF04, 3FF30, 3FF5B, 3FF86, 3FFB0, 3FFD9;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_2aedacd683e9a125',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '9285317e1b69761cd5e24df45f6f48d9',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_2aedacd683e9a125',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFFB, 3FFD2, 3FFA8, 3FF7E, 3FF53, 3FF28, 3FEFC, 3FECF, 3FEA1, 3FE72, 3FE42, 3FE10, 3FDDE, 3FDAA, 3FD74, 3FD3D, 3FD04, 3FCCA, 3FC8E, 3FC4F, 3FC0F, 3FBCD, 3FB89, 3FB43, 3FAFA, 3FAB0, 3FA63, 3FA13, 3F9C1, 3F96D, 3F916, 3F8BD, 3F861, 3F803, 3F7A2, 3F73F, 3F6D9, 3F671, 3F606, 3F598, 3F528, 3F4B6, 3F441, 3F3CA, 3F351, 3F2D6, 3F258, 3F1D8, 3F157, 3F0D3, 3F04E, 3EFC7, 3EF3F, 3EEB5, 3EE2A, 3ED9D, 3ED10, 3EC82, 3EBF3, 3EB64, 3EAD5, 3EA45, 3E9B6, 3E927, 3E899, 3E80B, 3E77F, 3E6F3, 3E669, 3E5E1, 3E55B, 3E4D7, 3E456, 3E3D8, 3E35D, 3E2E5, 3E271, 3E201, 3E196, 3E12F, 3E0CD, 3E071, 3E01A, 3DFC9, 3DF7F, 3DF3B, 3DEFF, 3DEC9, 3DE9C, 3DE77, 3DE5A, 3DE46, 3DE3C, 3DE3B, 3DE44, 3DE57, 3DE75, 3DE9E, 3DED2, 3DF13, 3DF5F, 3DFB8, 3E01E, 3E091, 3E111, 3E1A0, 3E23D, 3E2E8, 3E3A3, 3E46D, 3E546, 3E62F, 3E729, 3E833, 3E94E, 3EA7A, 3EBB8, 3ED07, 3EE68, 3EFDC, 3F162, 3F2FA, 3F4A6, 3F665, 3F837, 3FA1D, 3FC16, 3FE24;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_5f77990d4e3003ce',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '044872d86ec57ced104ea9aa7f5a8898',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_5f77990d4e3003ce',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 45, 27B, 4C5, 724, 997, C1E, EBB, 116C, 1433, 170E, 19FE, 1D02, 201C, 234B, 268E, 29E7, 2D53, 30D5, 346B, 3815, 3BD4, 3FA6, 438D, 4787, 4B94, 4FB5, 53E9, 582F, 5C88, 60F3, 6570, 69FF, 6E9E, 734F, 7810, 7CE1, 81C1, 86B1, 8BAF, 90BC, 95D6, 9AFE, A033, A574, AAC1, B019, B57B, BAE8, C05E, C5DD, CB65, D0F4, D68A, DC27, E1C9, E771, ED1D, F2CC, F87F, FE34, 103EB, 109A2, 10F5A, 11511, 11AC7, 1207B, 1262C, 12BDA, 13183, 13728, 13CC6, 1425E, 147EF, 14D78, 152F7, 1586E, 15DDA, 1633A, 1688F, 16DD8, 17313, 1783F, 17D5D, 1826C, 1876A, 18C57, 19132, 195FB, 19AB0, 19F52, 1A3DF, 1A857, 1ACB9, 1B104, 1B538, 1B955, 1BD58, 1C143, 1C514, 1C8CB, 1CC67, 1CFE7, 1D34C, 1D694, 1D9BF, 1DCCD, 1DFBD, 1E28F, 1E542, 1E7D5, 1EA49, 1EC9D, 1EED1, 1F0E4, 1F2D6, 1F4A6, 1F655, 1F7E2, 1F94D, 1FA96, 1FBBC, 1FCBF, 1FDA0, 1FE5D, 1FEF8, 1FF6F, 1FFC2, 1FFF3;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_bd9f37303f73021f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '956edd4d66a0bbae3810ae99e8e16ba4',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_bd9f37303f73021f',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFF, 1FFE9, 1FFAF, 1FF52, 1FED2, 1FE2E, 1FD67, 1FC7E, 1FB71, 1FA42, 1F8F0, 1F77C, 1F5E6, 1F42E, 1F255, 1F05A, 1EE3E, 1EC02, 1E9A5, 1E729, 1E48D, 1E1D2, 1DEF8, 1DC00, 1D8EB, 1D5B8, 1D268, 1CEFC, 1CB74, 1C7D1, 1C413, 1C03B, 1BC4A, 1B83F, 1B41D, 1AFE2, 1AB91, 1A729, 1A2AC, 19E19, 19972, 194B8, 18FEA, 18B0A, 18619, 18116, 17C04, 176E2, 171B1, 16C72, 16727, 161CF, 15C6B, 156FC, 15183, 14C01, 14676, 140E4, 13B4A, 135AA, 13004, 12A5A, 124AB, 11EF9, 11945, 1138F, 10DD7, 10820, 10269, FCB2, F6FE, F14C, EB9E, E5F3, E04D, DAAC, D511, CF7D, C9F0, C46B, BEEE, B97A, B410, AEB0, A95B, A412, 9ED4, 99A3, 947F, 8F68, 8A5F, 8565, 8079, 7B9D, 76D0, 7214, 6D68, 68CD, 6443, 5FCB, 5B65, 5711, 52D0, 4EA1, 4A86, 467D, 4288, 3EA7, 3ADA, 3721, 337C, 2FEC, 2C70, 2909, 25B6, 2278, 1F4F, 1C3B, 193C, 1651, 137C, 10BB, E10, B79, 8F7, 689, 430, 1EB;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_5c1c438679348ebe',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '96e67b55bfd67f6c2efabecb4d016815',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_5c1c438679348ebe',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFBB, 3FD9F, 3FB97, 3F9A3, 3F7C2, 3F5F5, 3F43C, 3F295, 3F101, 3EF80, 3EE12, 3ECB5, 3EB6B, 3EA32, 3E90A, 3E7F4, 3E6EE, 3E5F9, 3E514, 3E43E, 3E379, 3E2C2, 3E21B, 3E182, 3E0F7, 3E07A, 3E00A, 3DFA8, 3DF52, 3DF09, 3DECC, 3DE9A, 3DE74, 3DE59, 3DE48, 3DE42, 3DE46, 3DE53, 3DE69, 3DE88, 3DEAF, 3DEDE, 3DF15, 3DF54, 3DF99, 3DFE5, 3E037, 3E08F, 3E0ED, 3E150, 3E1B8, 3E225, 3E296, 3E30B, 3E383, 3E3FF, 3E47E, 3E500, 3E584, 3E60B, 3E693, 3E71D, 3E7A9, 3E836, 3E8C3, 3E952, 3E9E1, 3EA70, 3EAFF, 3EB8E, 3EC1D, 3ECAC, 3ED39, 3EDC6, 3EE52, 3EEDD, 3EF66, 3EFEE, 3F074, 3F0F9, 3F17C, 3F1FD, 3F27C, 3F2F9, 3F374, 3F3EC, 3F463, 3F4D7, 3F548, 3F5B7, 3F624, 3F68E, 3F6F6, 3F75B, 3F7BD, 3F81D, 3F87B, 3F8D6, 3F92E, 3F984, 3F9D8, 3FA29, 3FA78, 3FAC4, 3FB0E, 3FB56, 3FB9C, 3FBDF, 3FC21, 3FC60, 3FC9E, 3FCD9, 3FD13, 3FD4B, 3FD82, 3FDB7, 3FDEB, 3FE1D, 3FE4E, 3FE7E, 3FEAD, 3FEDA, 3FF07, 3FF33, 3FF5E, 3FF89, 3FFB3, 3FFDC;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_35ca7db3c4874218',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f0c3529eae1ff02f8eeec455217fe464',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_35ca7db3c4874218',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFF8, 3FFCF, 3FFA5, 3FF7B, 3FF51, 3FF25, 3FEF9, 3FECC, 3FE9E, 3FE6F, 3FE3F, 3FE0D, 3FDDA, 3FDA6, 3FD71, 3FD3A, 3FD01, 3FCC6, 3FC8A, 3FC4C, 3FC0B, 3FBC9, 3FB85, 3FB3E, 3FAF6, 3FAAB, 3FA5E, 3FA0E, 3F9BC, 3F968, 3F911, 3F8B7, 3F85C, 3F7FD, 3F79C, 3F739, 3F6D3, 3F66A, 3F5FF, 3F591, 3F521, 3F4AF, 3F43A, 3F3C3, 3F34A, 3F2CE, 3F250, 3F1D0, 3F14F, 3F0CB, 3F046, 3EFBE, 3EF36, 3EEAC, 3EE21, 3ED94, 3ED07, 3EC79, 3EBEA, 3EB5B, 3EACC, 3EA3D, 3E9AD, 3E91E, 3E890, 3E802, 3E776, 3E6EB, 3E661, 3E5D9, 3E553, 3E4CF, 3E44E, 3E3D0, 3E355, 3E2DE, 3E26A, 3E1FA, 3E18F, 3E129, 3E0C7, 3E06B, 3E015, 3DFC4, 3DF7A, 3DF37, 3DEFB, 3DEC6, 3DE9A, 3DE75, 3DE59, 3DE45, 3DE3B, 3DE3B, 3DE45, 3DE58, 3DE77, 3DEA1, 3DED6, 3DF17, 3DF64, 3DFBE, 3E025, 3E098, 3E11A, 3E1A9, 3E247, 3E2F4, 3E3AF, 3E47A, 3E554, 3E63E, 3E739, 3E844, 3E960, 3EA8D, 3EBCC, 3ED1D, 3EE7F, 3EFF4, 3F17B, 3F315, 3F4C1, 3F682, 3F855, 3FA3C, 3FC37, 3FE45;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_92ab33368f2cd867',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '1b689a1c42202e7205d26b37049e82c4',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_92ab33368f2cd867',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 68, 29F, 4EA, 74A, 9BF, C48, EE5, 1198, 1460, 173C, 1A2D, 1D33, 204F, 237E, 26C3, 2A1D, 2D8B, 310E, 34A5, 3850, 3C10, 3FE4, 43CC, 47C7, 4BD6, 4FF8, 542D, 5874, 5CCE, 613B, 65B9, 6A48, 6EE9, 739A, 785C, 7D2E, 8210, 8700, 8BFF, 910D, 9628, 9B51, A087, A5C8, AB16, B06E, B5D2, BB3F, C0B6, C636, CBBE, D14D, D6E4, DC81, E224, E7CC, ED78, F328, F8DA, FE8F, 10446, 109FE, 10FB5, 1156D, 11B22, 120D6, 12687, 12C35, 131DE, 13782, 13D20, 142B7, 14848, 14DD0, 1534F, 158C5, 15E30, 16390, 168E4, 16E2C, 17366, 17892, 17DAF, 182BC, 187B9, 18CA5, 1917F, 19647, 19AFB, 19F9B, 1A427, 1A89E, 1ACFE, 1B148, 1B57B, 1B995, 1BD98, 1C181, 1C550, 1C905, 1CCA0, 1D01E, 1D381, 1D6C8, 1D9F1, 1DCFD, 1DFEB, 1E2BB, 1E56C, 1E7FD, 1EA6F, 1ECC1, 1EEF3, 1F104, 1F2F4, 1F4C2, 1F66F, 1F7FA, 1F963, 1FAA9, 1FBCD, 1FCCE, 1FDAD, 1FE68, 1FF00, 1FF75, 1FFC6, 1FFF5;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_96ee7d5f7402f004',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '68501200457b1a3b0d7b2da45fc14624',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_96ee7d5f7402f004',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFF, 1FFE7, 1FFAB, 1FF4B, 1FEC9, 1FE23, 1FD5A, 1FC6E, 1FB5F, 1FA2E, 1F8DA, 1F764, 1F5CB, 1F411, 1F236, 1F039, 1EE1B, 1EBDD, 1E97F, 1E700, 1E462, 1E1A5, 1DECA, 1DBD0, 1D8B8, 1D584, 1D232, 1CEC4, 1CB3A, 1C796, 1C3D6, 1BFFD, 1BC0A, 1B7FE, 1B3DA, 1AF9E, 1AB4B, 1A6E2, 1A263, 19DCF, 19927, 1946B, 18F9D, 18ABB, 185C9, 180C5, 17BB2, 1768F, 1715E, 16C1E, 166D2, 16179, 15C14, 156A5, 1512C, 14BA9, 1461E, 1408A, 13AF0, 13550, 12FAA, 129FF, 12450, 11E9E, 118EA, 11333, 10D7C, 107C4, 1020D, FC57, F6A3, F0F1, EB43, E598, DFF3, DA52, D4B8, CF24, C997, C412, BE96, B923, B3BA, AE5B, A906, A3BE, 9E81, 9950, 942D, 8F17, 8A0F, 8516, 802B, 7B50, 7684, 71C9, 6D1E, 6884, 63FB, 5F84, 5B1F, 56CD, 528C, 4E5F, 4A44, 463D, 424A, 3E6A, 3A9E, 36E6, 3343, 2FB4, 2C39, 28D3, 2582, 2245, 1F1D, 1C0A, 190D, 1624, 134F, 1090, DE6, B50, 8CF, 663, 40B, 1C8;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_a85558f8d0175055',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '154390aac35d9b63c1828b8cb86b5617',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_a85558f8d0175055',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FF99, 3FD7E, 3FB77, 3F984, 3F7A5, 3F5D9, 3F421, 3F27B, 3F0E9, 3EF69, 3EDFB, 3ECA0, 3EB57, 3EA1F, 3E8F8, 3E7E3, 3E6DE, 3E5EA, 3E506, 3E432, 3E36D, 3E2B7, 3E211, 3E178, 3E0EE, 3E072, 3E004, 3DFA2, 3DF4D, 3DF05, 3DEC8, 3DE97, 3DE72, 3DE58, 3DE48, 3DE42, 3DE46, 3DE54, 3DE6A, 3DE8A, 3DEB2, 3DEE2, 3DF19, 3DF58, 3DF9E, 3DFEA, 3E03D, 3E095, 3E0F3, 3E157, 3E1BF, 3E22C, 3E29D, 3E312, 3E38B, 3E407, 3E486, 3E508, 3E58C, 3E613, 3E69C, 3E726, 3E7B1, 3E83E, 3E8CC, 3E95B, 3E9EA, 3EA79, 3EB08, 3EB97, 3EC26, 3ECB4, 3ED42, 3EDCF, 3EE5B, 3EEE5, 3EF6F, 3EFF6, 3F07D, 3F101, 3F184, 3F205, 3F284, 3F301, 3F37B, 3F3F4, 3F46A, 3F4DE, 3F54F, 3F5BE, 3F62B, 3F694, 3F6FC, 3F761, 3F7C3, 3F823, 3F881, 3F8DB, 3F934, 3F989, 3F9DD, 3FA2E, 3FA7C, 3FAC9, 3FB13, 3FB5A, 3FBA0, 3FBE3, 3FC25, 3FC64, 3FCA1, 3FCDD, 3FD17, 3FD4F, 3FD85, 3FDBA, 3FDEE, 3FE20, 3FE51, 3FE81, 3FEAF, 3FEDD, 3FF0A, 3FF36, 3FF61, 3FF8B, 3FFB5, 3FFDF;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_625b626db9d15258',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bc6c2c7205ea52d7c74d4b7181babb4c',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_625b626db9d15258',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFF6, 3FFCD, 3FFA3, 3FF79, 3FF4E, 3FF22, 3FEF6, 3FEC9, 3FE9B, 3FE6C, 3FE3C, 3FE0A, 3FDD7, 3FDA3, 3FD6D, 3FD36, 3FCFD, 3FCC2, 3FC86, 3FC48, 3FC07, 3FBC5, 3FB81, 3FB3A, 3FAF1, 3FAA6, 3FA59, 3FA09, 3F9B7, 3F962, 3F90B, 3F8B2, 3F856, 3F7F7, 3F796, 3F732, 3F6CC, 3F663, 3F5F8, 3F58A, 3F51A, 3F4A8, 3F433, 3F3BB, 3F342, 3F2C6, 3F248, 3F1C8, 3F146, 3F0C3, 3F03D, 3EFB6, 3EF2D, 3EEA3, 3EE18, 3ED8C, 3ECFE, 3EC70, 3EBE2, 3EB52, 3EAC3, 3EA34, 3E9A4, 3E915, 3E887, 3E7F9, 3E76D, 3E6E2, 3E658, 3E5D0, 3E54B, 3E4C7, 3E446, 3E3C8, 3E34E, 3E2D6, 3E263, 3E1F4, 3E189, 3E122, 3E0C1, 3E065, 3E00F, 3DFC0, 3DF76, 3DF33, 3DEF8, 3DEC3, 3DE97, 3DE73, 3DE57, 3DE44, 3DE3B, 3DE3B, 3DE45, 3DE5A, 3DE79, 3DEA4, 3DEDA, 3DF1B, 3DF69, 3DFC4, 3E02B, 3E0A0, 3E123, 3E1B3, 3E252, 3E2FF, 3E3BB, 3E487, 3E562, 3E64E, 3E749, 3E855, 3E973, 3EAA1, 3EBE1, 3ED32, 3EE96, 3F00C, 3F194, 3F32F, 3F4DD, 3F69E, 3F873, 3FA5B, 3FC57, 3FE67;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_1229603742632532',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '0254e9bd4dd3a628fb9a852fd2882686',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_1229603742632532',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 8B, 2C3, 510, 771, 9E7, C71, F10, 11C4, 148D, 176A, 1A5D, 1D65, 2081, 23B2, 26F8, 2A53, 2DC2, 3147, 34DF, 388C, 3C4D, 4022, 440B, 4807, 4C17, 503B, 5471, 58B9, 5D15, 6182, 6601, 6A92, 6F34, 73E6, 78A9, 7D7C, 825E, 8750, 8C50, 915E, 967B, 9BA4, A0DA, A61D, AB6B, B0C4, B628, BB96, C10E, C68E, CC16, D1A7, D73E, DCDB, E27E, E826, EDD3, F383, F936, FEEB, 104A2, 10A59, 11011, 115C8, 11B7E, 12131, 126E2, 12C8F, 13238, 137DC, 13D79, 14311, 148A0, 14E28, 153A7, 1591C, 15E86, 163E6, 16939, 16E80, 173B9, 178E4, 17E00, 1830D, 18808, 18CF3, 191CC, 19693, 19B46, 19FE5, 1A46F, 1A8E4, 1AD43, 1B18C, 1B5BD, 1B9D6, 1BDD7, 1C1BF, 1C58C, 1C940, 1CCD8, 1D055, 1D3B7, 1D6FB, 1DA23, 1DD2D, 1E019, 1E2E7, 1E596, 1E826, 1EA96, 1ECE5, 1EF15, 1F124, 1F312, 1F4DE, 1F689, 1F812, 1F978, 1FABD, 1FBDE, 1FCDD, 1FDB9, 1FE72, 1FF08, 1FF7B, 1FFCA, 1FFF6;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_6bd43647e92640a0',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '1979b91db9c92e37fe9bbb03c7e93872',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_6bd43647e92640a0',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFF, 1FFE4, 1FFA6, 1FF44, 1FEBF, 1FE17, 1FD4C, 1FC5E, 1FB4D, 1FA1A, 1F8C3, 1F74B, 1F5B1, 1F3F5, 1F217, 1F018, 1EDF8, 1EBB8, 1E958, 1E6D7, 1E437, 1E178, 1DE9B, 1DB9F, 1D886, 1D54F, 1D1FC, 1CE8C, 1CB01, 1C75A, 1C399, 1BFBE, 1BBCA, 1B7BC, 1B397, 1AF5A, 1AB05, 1A69B, 1A21B, 19D86, 198DC, 1941F, 18F4F, 18A6D, 18579, 18075, 17B60, 1763C, 1710A, 16BCA, 1667C, 16123, 15BBE, 1564E, 150D4, 14B50, 145C5, 14031, 13A96, 134F6, 12F4F, 129A4, 123F5, 11E43, 1188E, 112D8, 10D21, 10769, 101B2, FBFC, F648, F096, EAE8, E53E, DF98, D9F8, D45E, CECB, C93F, C3BA, BE3F, B8CC, B364, AE05, A8B2, A369, 9E2D, 98FE, 93DB, 8EC6, 89BF, 84C6, 7FDD, 7B02, 7638, 717E, 6CD4, 683B, 63B3, 5F3E, 5ADA, 5688, 5249, 4E1D, 4A03, 45FE, 420B, 3E2D, 3A62, 36AB, 3309, 2F7B, 2C02, 289D, 254D, 2212, 1EEC, 1BDA, 18DD, 15F6, 1323, 1065, DBC, B27, 8A8, 63D, 3E6, 1A4;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_de3dc1470c0610bb',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '73e84c18ac79e46d46f09f03566f4126',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_de3dc1470c0610bb',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FF76, 3FD5D, 3FB57, 3F966, 3F788, 3F5BD, 3F406, 3F261, 3F0D0, 3EF51, 3EDE5, 3EC8B, 3EB43, 3EA0C, 3E8E6, 3E7D2, 3E6CE, 3E5DB, 3E4F8, 3E425, 3E361, 3E2AC, 3E207, 3E16F, 3E0E6, 3E06B, 3DFFD, 3DF9C, 3DF48, 3DF00, 3DEC5, 3DE95, 3DE70, 3DE56, 3DE47, 3DE42, 3DE47, 3DE55, 3DE6C, 3DE8C, 3DEB4, 3DEE5, 3DF1D, 3DF5C, 3DFA2, 3DFEF, 3E042, 3E09B, 3E0F9, 3E15D, 3E1C6, 3E233, 3E2A4, 3E31A, 3E392, 3E40F, 3E48E, 3E510, 3E595, 3E61C, 3E6A4, 3E72F, 3E7BA, 3E847, 3E8D5, 3E964, 3E9F3, 3EA82, 3EB11, 3EBA0, 3EC2F, 3ECBD, 3ED4B, 3EDD8, 3EE63, 3EEEE, 3EF77, 3EFFF, 3F085, 3F109, 3F18C, 3F20D, 3F28C, 3F308, 3F383, 3F3FB, 3F471, 3F4E5, 3F556, 3F5C5, 3F631, 3F69B, 3F702, 3F767, 3F7C9, 3F829, 3F886, 3F8E1, 3F939, 3F98F, 3F9E2, 3FA33, 3FA81, 3FACD, 3FB17, 3FB5F, 3FBA4, 3FBE7, 3FC29, 3FC68, 3FCA5, 3FCE1, 3FD1A, 3FD52, 3FD89, 3FDBE, 3FDF1, 3FE23, 3FE54, 3FE84, 3FEB2, 3FEE0, 3FF0D, 3FF38, 3FF63, 3FF8E, 3FFB8, 3FFE1;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_1b1f529848dd4f32',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '63f28ec43cb6169a121e5419061b9644',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_1b1f529848dd4f32',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFF3, 3FFCA, 3FFA0, 3FF76, 3FF4B, 3FF20, 3FEF3, 3FEC6, 3FE98, 3FE69, 3FE39, 3FE07, 3FDD4, 3FDA0, 3FD6A, 3FD33, 3FCF9, 3FCBF, 3FC82, 3FC44, 3FC03, 3FBC1, 3FB7C, 3FB35, 3FAED, 3FAA1, 3FA54, 3FA04, 3F9B2, 3F95D, 3F906, 3F8AC, 3F850, 3F7F1, 3F790, 3F72C, 3F6C6, 3F65D, 3F5F1, 3F584, 3F513, 3F4A0, 3F42B, 3F3B4, 3F33A, 3F2BE, 3F240, 3F1C0, 3F13E, 3F0BA, 3F035, 3EFAE, 3EF25, 3EE9B, 3EE0F, 3ED83, 3ECF5, 3EC67, 3EBD9, 3EB49, 3EABA, 3EA2B, 3E99B, 3E90C, 3E87E, 3E7F1, 3E764, 3E6D9, 3E650, 3E5C8, 3E542, 3E4BF, 3E43E, 3E3C1, 3E346, 3E2CF, 3E25C, 3E1ED, 3E182, 3E11C, 3E0BB, 3E060, 3E00A, 3DFBB, 3DF72, 3DF2F, 3DEF4, 3DEC0, 3DE94, 3DE71, 3DE56, 3DE44, 3DE3B, 3DE3C, 3DE46, 3DE5C, 3DE7C, 3DEA7, 3DEDD, 3DF20, 3DF6F, 3DFCA, 3E032, 3E0A8, 3E12B, 3E1BC, 3E25C, 3E30A, 3E3C8, 3E494, 3E571, 3E65D, 3E75A, 3E867, 3E985, 3EAB4, 3EBF5, 3ED48, 3EEAD, 3F024, 3F1AD, 3F349, 3F4F8, 3F6BB, 3F891, 3FA7A, 3FC77, 3FE89;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_745123e7a5579ed6',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '30a222017516c1c9fc89ce301e093e61',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_745123e7a5579ed6',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = AE, 2E7, 535, 798, A0F, C9A, F3B, 11F0, 14BA, 1799, 1A8D, 1D96, 20B3, 23E6, 272D, 2A89, 2DFA, 317F, 3519, 38C7, 3C8A, 4060, 444A, 4848, 4C59, 507D, 54B5, 58FF, 5D5B, 61C9, 664A, 6ADB, 6F7E, 7432, 78F6, 7DC9, 82AD, 879F, 8CA0, 91B0, 96CD, 9BF7, A12E, A671, ABC0, B11A, B67F, BBED, C165, C6E6, CC6F, D200, D797, DD35, E2D8, E881, EE2D, F3DE, F991, FF46, 104FD, 10AB5, 1106C, 11623, 11BD9, 1218C, 1273D, 12CEA, 13292, 13836, 13DD3, 1436A, 148F9, 14E80, 153FE, 15973, 15EDD, 1643B, 1698E, 16ED4, 1740C, 17936, 17E51, 1835D, 18858, 18D41, 19219, 196DE, 19B90, 1A02E, 1A4B7, 1A92B, 1AD89, 1B1D0, 1B5FF, 1BA17, 1BE16, 1C1FC, 1C5C8, 1C97A, 1CD11, 1D08C, 1D3EC, 1D72F, 1DA54, 1DD5D, 1E047, 1E313, 1E5C0, 1E84D, 1EABB, 1ED09, 1EF37, 1F144, 1F32F, 1F4FA, 1F6A2, 1F829, 1F98E, 1FAD0, 1FBEF, 1FCEC, 1FDC6, 1FE7D, 1FF11, 1FF81, 1FFCE, 1FFF8;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_124343a412039b8c',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'cbd04ca8d7fd98b74b3b9eec334e6fc4',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_124343a412039b8c',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFE, 1FFE1, 1FFA1, 1FF3D, 1FEB6, 1FE0C, 1FD3E, 1FC4E, 1FB3B, 1FA05, 1F8AD, 1F732, 1F596, 1F3D8, 1F1F8, 1EFF7, 1EDD5, 1EB93, 1E930, 1E6AE, 1E40C, 1E14C, 1DE6C, 1DB6F, 1D853, 1D51B, 1D1C6, 1CE54, 1CAC7, 1C71F, 1C35C, 1BF80, 1BB8A, 1B77B, 1B354, 1AF15, 1AABF, 1A653, 1A1D2, 19D3C, 19891, 193D3, 18F01, 18A1E, 18529, 18024, 17B0E, 175EA, 170B6, 16B75, 16627, 160CD, 15B67, 155F6, 1507C, 14AF8, 1456C, 13FD7, 13A3C, 1349B, 12EF5, 12949, 1239A, 11DE8, 11833, 1127C, 10CC5, 1070D, 10156, FBA0, F5EC, F03B, EA8D, E4E3, DF3E, D99F, D405, CE72, C8E6, C362, BDE7, B875, B30D, ADB0, A85D, A315, 9DDA, 98AB, 9389, 8E75, 896F, 8477, 7F8F, 7AB5, 75EC, 7132, 6C8A, 67F2, 636C, 5EF7, 5A94, 5643, 5206, 4DDA, 49C2, 45BE, 41CD, 3DEF, 3A26, 3671, 32D0, 2F43, 2BCB, 2868, 2519, 21DF, 1EBA, 1BAA, 18AE, 15C8, 12F6, 103A, D92, AFF, 880, 617, 3C2, 181;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_22c9531bf9d9931d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '20a73f0a2569dd7a8b295302d7efae25',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_22c9531bf9d9931d',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FF54, 3FD3C, 3FB38, 3F947, 3F76A, 3F5A1, 3F3EB, 3F248, 3F0B8, 3EF3A, 3EDCF, 3EC76, 3EB2F, 3E9F9, 3E8D5, 3E7C1, 3E6BF, 3E5CD, 3E4EA, 3E418, 3E355, 3E2A2, 3E1FD, 3E166, 3E0DE, 3E064, 3DFF7, 3DF97, 3DF43, 3DEFC, 3DEC1, 3DE92, 3DE6E, 3DE55, 3DE46, 3DE42, 3DE47, 3DE56, 3DE6E, 3DE8E, 3DEB7, 3DEE8, 3DF20, 3DF60, 3DFA7, 3DFF4, 3E047, 3E0A1, 3E0FF, 3E163, 3E1CC, 3E23A, 3E2AB, 3E321, 3E39A, 3E417, 3E496, 3E518, 3E59D, 3E624, 3E6AD, 3E737, 3E7C3, 3E850, 3E8DE, 3E96C, 3E9FB, 3EA8B, 3EB1A, 3EBA9, 3EC38, 3ECC6, 3ED54, 3EDE0, 3EE6C, 3EEF7, 3EF80, 3F007, 3F08D, 3F112, 3F194, 3F215, 3F294, 3F310, 3F38B, 3F403, 3F478, 3F4EC, 3F55D, 3F5CC, 3F638, 3F6A2, 3F709, 3F76D, 3F7CF, 3F82F, 3F88C, 3F8E6, 3F93E, 3F994, 3F9E7, 3FA38, 3FA86, 3FAD2, 3FB1C, 3FB63, 3FBA8, 3FBEB, 3FC2D, 3FC6C, 3FCA9, 3FCE4, 3FD1E, 3FD56, 3FD8C, 3FDC1, 3FDF4, 3FE26, 3FE57, 3FE87, 3FEB5, 3FEE3, 3FF0F, 3FF3B, 3FF66, 3FF91, 3FFBA, 3FFE4;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_c4962da8045cf294',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '02c908c13d085d667d9721879f5030b9',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_c4962da8045cf294',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFF1, 3FFC7, 3FF9E, 3FF73, 3FF49, 3FF1D, 3FEF1, 3FEC3, 3FE95, 3FE66, 3FE35, 3FE04, 3FDD1, 3FD9C, 3FD66, 3FD2F, 3FCF6, 3FCBB, 3FC7E, 3FC40, 3FBFF, 3FBBD, 3FB78, 3FB31, 3FAE8, 3FA9D, 3FA4F, 3F9FF, 3F9AC, 3F958, 3F900, 3F8A6, 3F84A, 3F7EB, 3F78A, 3F726, 3F6BF, 3F656, 3F5EB, 3F57D, 3F50C, 3F499, 3F424, 3F3AC, 3F333, 3F2B6, 3F238, 3F1B8, 3F136, 3F0B2, 3F02C, 3EFA5, 3EF1C, 3EE92, 3EE07, 3ED7A, 3ECED, 3EC5E, 3EBD0, 3EB40, 3EAB1, 3EA22, 3E992, 3E904, 3E875, 3E7E8, 3E75C, 3E6D1, 3E647, 3E5C0, 3E53A, 3E4B7, 3E436, 3E3B9, 3E33F, 3E2C8, 3E255, 3E1E6, 3E17C, 3E116, 3E0B5, 3E05A, 3E005, 3DFB6, 3DF6D, 3DF2B, 3DEF1, 3DEBD, 3DE92, 3DE6F, 3DE54, 3DE43, 3DE3B, 3DE3C, 3DE47, 3DE5D, 3DE7E, 3DEAA, 3DEE1, 3DF25, 3DF74, 3DFD0, 3E039, 3E0B0, 3E134, 3E1C6, 3E266, 3E316, 3E3D4, 3E4A2, 3E57F, 3E66C, 3E76A, 3E878, 3E997, 3EAC8, 3EC0A, 3ED5E, 3EEC3, 3F03C, 3F1C6, 3F364, 3F514, 3F6D8, 3F8AF, 3FA99, 3FC98, 3FEAA;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_1c1618792e7b4b17',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd1bc19a7b3ceb41bae70f501431fbe0e',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_1c1618792e7b4b17',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = D1, 30C, 55B, 7BE, A37, CC4, F65, 121C, 14E7, 17C8, 1ABD, 1DC7, 20E6, 241A, 2762, 2AC0, 2E32, 31B8, 3554, 3903, 3CC6, 409E, 4489, 4888, 4C9B, 50C0, 54F9, 5944, 5DA1, 6211, 6692, 6B25, 6FC9, 747D, 7942, 7E17, 82FB, 87EF, 8CF1, 9201, 971F, 9C4A, A182, A6C6, AC16, B170, B6D5, BC45, C1BD, C73F, CCC8, D259, D7F1, DD8F, E333, E8DB, EE88, F439, F9EC, FFA2, 10559, 10B10, 110C8, 1167F, 11C34, 121E8, 12798, 12D45, 132ED, 13890, 13E2D, 143C3, 14952, 14ED8, 15456, 159CA, 15F33, 16491, 169E3, 16F28, 1745F, 17988, 17EA3, 183AD, 188A7, 18D8F, 19266, 1972A, 19BDB, 1A077, 1A4FF, 1A971, 1ADCE, 1B213, 1B642, 1BA58, 1BE55, 1C23A, 1C604, 1C9B4, 1CD49, 1D0C3, 1D421, 1D762, 1DA86, 1DD8C, 1E075, 1E33E, 1E5EA, 1E875, 1EAE1, 1ED2D, 1EF59, 1F163, 1F34D, 1F515, 1F6BC, 1F840, 1F9A3, 1FAE3, 1FC00, 1FCFB, 1FDD2, 1FE87, 1FF19, 1FF87, 1FFD2, 1FFF9;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_bb1657683745558f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '25b115d87925f0532ca4a88d4cf2d28e',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_bb1657683745558f',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFD, 1FFDE, 1FF9C, 1FF36, 1FEAC, 1FE00, 1FD30, 1FC3E, 1FB29, 1F9F1, 1F896, 1F71A, 1F57B, 1F3BB, 1F1D9, 1EFD6, 1EDB2, 1EB6E, 1E909, 1E685, 1E3E1, 1E11E, 1DE3D, 1DB3E, 1D821, 1D4E6, 1D18F, 1CE1C, 1CA8E, 1C6E4, 1C31F, 1BF41, 1BB49, 1B739, 1B310, 1AED0, 1AA79, 1A60C, 1A189, 19CF1, 19845, 19386, 18EB4, 189CF, 184D9, 17FD3, 17ABC, 17597, 17063, 16B21, 165D2, 16077, 15B10, 1559F, 15024, 14A9F, 14512, 13F7E, 139E3, 13441, 12E9A, 128EF, 1233F, 11D8D, 117D8, 11221, 10C6A, 106B2, 100FB, FB45, F591, EFE0, EA33, E489, DEE4, D945, D3AB, CE19, C88E, C30B, BD90, B81F, B2B7, AD5A, A808, A2C1, 9D87, 9859, 9338, 8E24, 891F, 8428, 7F41, 7A68, 75A0, 70E7, 6C40, 67A9, 6324, 5EB0, 5A4E, 55FF, 51C2, 4D98, 4982, 457E, 418E, 3DB2, 39EA, 3636, 3296, 2F0B, 2B94, 2832, 24E5, 21AC, 1E88, 1B79, 187F, 159A, 12CA, 100F, D68, AD6, 859, 5F1, 39D, 15D;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_9d82ac685295034d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '84cf96abfd8c2e4c73bbc6a50156aebb',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_9d82ac685295034d',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FF32, 3FD1B, 3FB18, 3F929, 3F74D, 3F585, 3F3D0, 3F22E, 3F09F, 3EF23, 3EDB9, 3EC61, 3EB1B, 3E9E6, 3E8C3, 3E7B1, 3E6AF, 3E5BE, 3E4DD, 3E40C, 3E34A, 3E297, 3E1F3, 3E15D, 3E0D6, 3E05C, 3DFF0, 3DF91, 3DF3F, 3DEF8, 3DEBE, 3DE90, 3DE6C, 3DE54, 3DE46, 3DE42, 3DE48, 3DE57, 3DE70, 3DE91, 3DEBA, 3DEEB, 3DF24, 3DF64, 3DFAB, 3DFF9, 3E04D, 3E0A6, 3E106, 3E16A, 3E1D3, 3E241, 3E2B3, 3E328, 3E3A2, 3E41F, 3E49E, 3E521, 3E5A5, 3E62C, 3E6B5, 3E740, 3E7CC, 3E859, 3E8E7, 3E975, 3EA04, 3EA94, 3EB23, 3EBB2, 3EC41, 3ECCF, 3ED5D, 3EDE9, 3EE75, 3EEFF, 3EF88, 3F010, 3F096, 3F11A, 3F19C, 3F21D, 3F29B, 3F318, 3F392, 3F40A, 3F480, 3F4F3, 3F564, 3F5D3, 3F63F, 3F6A8, 3F70F, 3F774, 3F7D5, 3F835, 3F892, 3F8EC, 3F944, 3F999, 3F9EC, 3FA3D, 3FA8B, 3FAD7, 3FB20, 3FB67, 3FBAD, 3FBF0, 3FC31, 3FC70, 3FCAD, 3FCE8, 3FD21, 3FD59, 3FD8F, 3FDC4, 3FDF7, 3FE29, 3FE5A, 3FE8A, 3FEB8, 3FEE5, 3FF12, 3FF3E, 3FF69, 3FF93, 3FFBD, 3FFE6;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_d8463bed3c6c2450',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '0fb073533033e284177f5821d0df5e13',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_d8463bed3c6c2450',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFEE, 3FFC5, 3FF9B, 3FF71, 3FF46, 3FF1A, 3FEEE, 3FEC1, 3FE92, 3FE63, 3FE32, 3FE01, 3FDCE, 3FD99, 3FD63, 3FD2B, 3FCF2, 3FCB7, 3FC7A, 3FC3C, 3FBFB, 3FBB8, 3FB73, 3FB2C, 3FAE3, 3FA98, 3FA4A, 3F9FA, 3F9A7, 3F952, 3F8FB, 3F8A1, 3F844, 3F7E5, 3F783, 3F71F, 3F6B9, 3F650, 3F5E4, 3F576, 3F505, 3F492, 3F41D, 3F3A5, 3F32B, 3F2AF, 3F230, 3F1B0, 3F12E, 3F0AA, 3F024, 3EF9C, 3EF14, 3EE89, 3EDFE, 3ED71, 3ECE4, 3EC56, 3EBC7, 3EB38, 3EAA8, 3EA19, 3E989, 3E8FB, 3E86C, 3E7DF, 3E753, 3E6C8, 3E63F, 3E5B7, 3E532, 3E4AF, 3E42E, 3E3B1, 3E337, 3E2C0, 3E24E, 3E1DF, 3E175, 3E110, 3E0B0, 3E055, 3E000, 3DFB1, 3DF69, 3DF27, 3DEED, 3DEBA, 3DE90, 3DE6D, 3DE53, 3DE42, 3DE3A, 3DE3C, 3DE49, 3DE5F, 3DE80, 3DEAD, 3DEE5, 3DF29, 3DF79, 3DFD6, 3E040, 3E0B8, 3E13D, 3E1D0, 3E271, 3E321, 3E3E0, 3E4AF, 3E58D, 3E67C, 3E77A, 3E88A, 3E9AA, 3EADC, 3EC1F, 3ED73, 3EEDA, 3F054, 3F1DF, 3F37E, 3F530, 3F6F5, 3F8CD, 3FAB9, 3FCB8, 3FECC;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_e2d739cfa89fc397',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '59e22c8a9dc61961014ca6ddd5cac444',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_e2d739cfa89fc397',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = F4, 330, 580, 7E5, A5F, CED, F90, 1248, 1515, 17F6, 1AED, 1DF8, 2119, 244E, 2798, 2AF6, 2E6A, 31F2, 358E, 393F, 3D03, 40DC, 44C9, 48C9, 4CDC, 5103, 553D, 5989, 5DE8, 6259, 66DB, 6B6F, 7014, 74C9, 798F, 7E65, 834A, 883F, 8D42, 9253, 9771, 9C9D, A1D6, A71B, AC6B, B1C6, B72C, BC9C, C215, C797, CD21, D2B2, D84B, DDE9, E38D, E936, EEE3, F494, FA47, FFFD, 105B4, 10B6C, 11123, 116DA, 11C90, 12243, 127F3, 12D9F, 13347, 138EA, 13E86, 1441C, 149AA, 14F30, 154AD, 15A21, 15F89, 164E6, 16A37, 16F7C, 174B2, 179DA, 17EF4, 183FD, 188F6, 18DDD, 192B3, 19776, 19C25, 1A0C0, 1A547, 1A9B8, 1AE13, 1B257, 1B684, 1BA98, 1BE94, 1C277, 1C640, 1C9EE, 1CD82, 1D0FA, 1D456, 1D795, 1DAB7, 1DDBC, 1E0A2, 1E36A, 1E613, 1E89D, 1EB07, 1ED51, 1EF7A, 1F183, 1F36A, 1F531, 1F6D5, 1F857, 1F9B8, 1FAF6, 1FC11, 1FD09, 1FDDF, 1FE91, 1FF21, 1FF8D, 1FFD5, 1FFFB;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_26f8ee760f443ce9',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '3d256d4b7cc82e00abcdbbc62d0f9469',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_26f8ee760f443ce9',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFC, 1FFDB, 1FF96, 1FF2E, 1FEA3, 1FDF4, 1FD22, 1FC2E, 1FB16, 1F9DC, 1F880, 1F701, 1F560, 1F39E, 1F1BA, 1EFB5, 1ED8F, 1EB48, 1E8E2, 1E65C, 1E3B6, 1E0F1, 1DE0E, 1DB0D, 1D7EE, 1D4B2, 1D159, 1CDE4, 1CA54, 1C6A8, 1C2E2, 1BF02, 1BB09, 1B6F7, 1B2CD, 1AE8B, 1AA33, 1A5C4, 1A140, 19CA7, 197FA, 19339, 18E66, 18980, 1848A, 17F82, 17A6B, 17544, 1700F, 16ACC, 1657D, 16021, 15AB9, 15548, 14FCC, 14A47, 144B9, 13F24, 13989, 133E7, 12E3F, 12894, 122E4, 11D31, 1177C, 111C6, 10C0E, 10656, 1009F, FAEA, F536, EF85, E9D8, E42F, DE8A, D8EB, D352, CDC0, C835, C2B3, BD39, B7C8, B261, AD05, A7B3, A26D, 9D33, 9806, 92E6, 8DD4, 88CF, 83D9, 7EF3, 7A1B, 7554, 709C, 6BF6, 6760, 62DC, 5E69, 5A09, 55BB, 517F, 4D56, 4941, 453F, 4150, 3D75, 39AE, 35FB, 325D, 2ED3, 2B5D, 27FD, 24B0, 2179, 1E57, 1B49, 1850, 156D, 129E, FE4, D3E, AAE, 832, 5CB, 378, 13A;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_1feb3ca5e406aaac',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '99b1c74bf8281b8002000b2a5fcd342c',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_1feb3ca5e406aaac',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FF10, 3FCFA, 3FAF8, 3F90A, 3F730, 3F569, 3F3B5, 3F215, 3F087, 3EF0C, 3EDA3, 3EC4C, 3EB07, 3E9D3, 3E8B1, 3E7A0, 3E6A0, 3E5AF, 3E4CF, 3E3FF, 3E33E, 3E28C, 3E1E9, 3E155, 3E0CE, 3E055, 3DFEA, 3DF8C, 3DF3A, 3DEF4, 3DEBB, 3DE8D, 3DE6A, 3DE53, 3DE45, 3DE42, 3DE49, 3DE58, 3DE71, 3DE93, 3DEBD, 3DEEF, 3DF28, 3DF69, 3DFB0, 3DFFE, 3E052, 3E0AC, 3E10C, 3E170, 3E1DA, 3E248, 3E2BA, 3E330, 3E3AA, 3E426, 3E4A6, 3E529, 3E5AE, 3E635, 3E6BE, 3E749, 3E7D5, 3E862, 3E8F0, 3E97E, 3EA0D, 3EA9D, 3EB2C, 3EBBB, 3EC4A, 3ECD8, 3ED65, 3EDF2, 3EE7D, 3EF08, 3EF91, 3F018, 3F09E, 3F122, 3F1A4, 3F225, 3F2A3, 3F320, 3F39A, 3F412, 3F487, 3F4FA, 3F56B, 3F5D9, 3F645, 3F6AF, 3F715, 3F77A, 3F7DC, 3F83B, 3F897, 3F8F2, 3F949, 3F99F, 3F9F1, 3FA42, 3FA90, 3FADB, 3FB25, 3FB6C, 3FBB1, 3FBF4, 3FC35, 3FC73, 3FCB0, 3FCEC, 3FD25, 3FD5D, 3FD93, 3FDC7, 3FDFB, 3FE2D, 3FE5D, 3FE8D, 3FEBB, 3FEE8, 3FF15, 3FF40, 3FF6B, 3FF96, 3FFC0, 3FFE9;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_98290a361b743d3a',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '4ac1083f81876dde54a76fa7cf2b520f',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_98290a361b743d3a',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FFEB, 3FFC2, 3FF98, 3FF6E, 3FF43, 3FF17, 3FEEB, 3FEBE, 3FE8F, 3FE60, 3FE2F, 3FDFD, 3FDCA, 3FD96, 3FD60, 3FD28, 3FCEF, 3FCB3, 3FC77, 3FC38, 3FBF7, 3FBB4, 3FB6F, 3FB28, 3FADF, 3FA93, 3FA45, 3F9F5, 3F9A2, 3F94D, 3F8F5, 3F89B, 3F83E, 3F7DF, 3F77D, 3F719, 3F6B2, 3F649, 3F5DD, 3F56F, 3F4FE, 3F48B, 3F415, 3F39D, 3F323, 3F2A7, 3F228, 3F1A8, 3F126, 3F0A1, 3F01C, 3EF94, 3EF0B, 3EE81, 3EDF5, 3ED68, 3ECDB, 3EC4D, 3EBBE, 3EB2F, 3EA9F, 3EA10, 3E980, 3E8F2, 3E864, 3E7D6, 3E74A, 3E6BF, 3E636, 3E5AF, 3E529, 3E4A7, 3E427, 3E3A9, 3E32F, 3E2B9, 3E247, 3E1D8, 3E16F, 3E10A, 3E0AA, 3E04F, 3DFFB, 3DFAD, 3DF65, 3DF24, 3DEEA, 3DEB8, 3DE8D, 3DE6B, 3DE52, 3DE41, 3DE3A, 3DE3D, 3DE4A, 3DE61, 3DE83, 3DEB0, 3DEE9, 3DF2E, 3DF7F, 3DFDD, 3E047, 3E0BF, 3E145, 3E1D9, 3E27C, 3E32D, 3E3ED, 3E4BC, 3E59C, 3E68B, 3E78B, 3E89B, 3E9BD, 3EAEF, 3EC33, 3ED89, 3EEF1, 3F06C, 3F1F9, 3F399, 3F54B, 3F711, 3F8EB, 3FAD8, 3FCD9, 3FEEE;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_9494f8e2a3baa04f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '1e49a98f93fe40b977d9cf0e1aa014af',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_9494f8e2a3baa04f',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 117, 354, 5A6, 80C, A87, D17, FBB, 1274, 1542, 1825, 1B1D, 1E2A, 214B, 2482, 27CD, 2B2D, 2EA2, 322B, 35C8, 397A, 3D40, 411A, 4508, 490A, 4D1E, 5146, 5581, 59CF, 5E2E, 62A0, 6724, 6BB9, 705F, 7515, 79DC, 7EB3, 8399, 888E, 8D92, 92A4, 97C4, 9CF0, A22A, A76F, ACC0, B21C, B783, BCF3, C26D, C7EF, CD7A, D30C, D8A4, DE43, E3E8, E991, EF3E, F4EF, FAA3, 10058, 10610, 10BC7, 1117F, 11736, 11CEB, 1229E, 1284E, 12DFA, 133A1, 13944, 13EE0, 14475, 14A03, 14F89, 15505, 15A77, 15FDF, 1653C, 16A8C, 16FCF, 17505, 17A2D, 17F45, 1844D, 18945, 18E2B, 19300, 197C1, 19C6F, 1A109, 1A58F, 1A9FE, 1AE58, 1B29A, 1B6C6, 1BAD9, 1BED3, 1C2B4, 1C67C, 1CA28, 1CDBA, 1D130, 1D48A, 1D7C8, 1DAE8, 1DDEB, 1E0CF, 1E396, 1E63D, 1E8C4, 1EB2D, 1ED74, 1EF9C, 1F1A2, 1F388, 1F54C, 1F6EE, 1F86E, 1F9CD, 1FB08, 1FC21, 1FD18, 1FDEB, 1FE9B, 1FF28, 1FF92, 1FFD9, 1FFFC;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_3a11a4c612b3cf88',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '7b8671bfdff8ca92f7b43b0b389e3df5',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_3a11a4c612b3cf88',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 1FFFB, 1FFD8, 1FF91, 1FF26, 1FE99, 1FDE8, 1FD14, 1FC1D, 1FB03, 1F9C7, 1F869, 1F6E8, 1F545, 1F380, 1F19A, 1EF93, 1ED6B, 1EB23, 1E8BA, 1E632, 1E38B, 1E0C4, 1DDDF, 1DADC, 1D7BB, 1D47D, 1D123, 1CDAC, 1CA1A, 1C66D, 1C2A5, 1BEC4, 1BAC9, 1B6B5, 1B28A, 1AE47, 1A9ED, 1A57D, 1A0F7, 19C5D, 197AF, 192ED, 18E18, 18932, 1843A, 17F31, 17A19, 174F1, 16FBB, 16A78, 16527, 15FCB, 15A63, 154F0, 14F74, 149EE, 14460, 13ECB, 1392F, 1338C, 12DE5, 12839, 12289, 11CD6, 11721, 1116A, 10BB3, 105FB, 10044, FA8F, F4DB, EF2A, E97D, E3D4, DE30, D891, D2F9, CD67, C7DD, C25B, BCE1, B771, B20B, ACAF, A75E, A219, 9CE0, 97B4, 9295, 8D83, 8880, 838B, 7EA5, 79CE, 7508, 7052, 6BAC, 6717, 6294, 5E23, 59C4, 5576, 513C, 4D15, 4900, 44FF, 4112, 3D38, 3972, 35C1, 3224, 2E9B, 2B27, 27C7, 247C, 2146, 1E25, 1B19, 1821, 153F, 1271, FB9, D15, A86, 80B, 5A5, 354, 117;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_02554aed8a90129f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '91ff8793309b22f58061a13b71bc5d32',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_02554aed8a90129f',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator virtex6 Xilinx,_Inc. 7.2',
    '# 14.6_P.66',
    '# DEVICE virtex6',
    '# VHDL',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = false',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 3FEEE, 3FCDA, 3FAD9, 3F8EC, 3F713, 3F54D, 3F39B, 3F1FB, 3F06F, 3EEF5, 3ED8D, 3EC37, 3EAF3, 3E9C1, 3E8A0, 3E790, 3E690, 3E5A1, 3E4C2, 3E3F2, 3E333, 3E282, 3E1E0, 3E14C, 3E0C6, 3E04E, 3DFE4, 3DF86, 3DF35, 3DEF0, 3DEB8, 3DE8B, 3DE69, 3DE51, 3DE45, 3DE42, 3DE49, 3DE5A, 3DE73, 3DE95, 3DEC0, 3DEF2, 3DF2C, 3DF6D, 3DFB5, 3E003, 3E058, 3E0B2, 3E112, 3E177, 3E1E0, 3E24F, 3E2C1, 3E337, 3E3B1, 3E42E, 3E4AE, 3E531, 3E5B6, 3E63E, 3E6C7, 3E751, 3E7DD, 3E86B, 3E8F9, 3E987, 3EA16, 3EAA6, 3EB35, 3EBC4, 3EC53, 3ECE1, 3ED6E, 3EDFB, 3EE86, 3EF10, 3EF99, 3F021, 3F0A6, 3F12A, 3F1AD, 3F22D, 3F2AB, 3F327, 3F3A1, 3F419, 3F48E, 3F501, 3F572, 3F5E0, 3F64C, 3F6B5, 3F71C, 3F780, 3F7E2, 3F841, 3F89D, 3F8F7, 3F94F, 3F9A4, 3F9F6, 3FA47, 3FA94, 3FAE0, 3FB29, 3FB70, 3FBB5, 3FBF8, 3FC39, 3FC77, 3FCB4, 3FCEF, 3FD29, 3FD60, 3FD96, 3FDCB, 3FDFE, 3FE30, 3FE60, 3FE8F, 3FEBE, 3FEEB, 3FF18, 3FF43, 3FF6E, 3FF98, 3FFC2, 3FFEB;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET ecc = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Always_Enabled',
    'CSET error_injection_type = Single_Bit_Error_Injection',
    'CSET fill_remaining_memory_locations = false',
    'CSET load_init_file = TRUE',
    'CSET memory_type = Single_Port_ROM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET pipeline_stages = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 18',
    'CSET read_width_b = 18',
    'CSET register_porta_output_of_memory_core = false',
    'CSET register_porta_output_of_memory_primitives = true',
    'CSET register_portb_output_of_memory_core = false',
    'CSET register_portb_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET reset_type = SYNC',
    'CSET use_byte_write_enable = false',
    'CSET use_error_injection_pins = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_rsta_pin = false',
    'CSET use_rstb_pin = false',
    'CSET write_depth_a = 128',
    'CSET write_width_a = 18',
    'CSET write_width_b = 18',
    'CSET component_name = bmg_72_3b2ab4c4014eb095',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '7a382193836eb7007c618c93fe4079e7',
    'sourceFile' => 'hdl/xlsprom.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      addra: in std_logic_vector(c_address_width - 1 downto 0);
      clka: in std_logic;
      ena: in std_logic;
      douta: out std_logic_vector(c_width - 1 downto 0)',
      'core_instance_text' => '        addra => core_addr,
        clka => clk,
        ena => core_ce,
        douta => core_data_out',
      'core_name0' => 'bmg_72_3b2ab4c4014eb095',
      'entityName' => 'xlsprom_pfb4t11_bb',
      'entity_name.0' => 'xlsprom',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a9775c856190c647d5ea2016094d923d',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xlconvert_pipeline.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '86b93eac138e214bd9f3dfbfc1ff35d5',
    'sourceFile' => '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'aa61abbc787a2ca466415d3e0d419cb6',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal ip_17_23: signed((26 - 1) downto 0);
begin
  ip_17_23 <= std_logic_vector_to_signed(ip);
  op <= signed_to_std_logic_vector(ip_17_23);
end',
      'crippled_entity' => 'is
  port (
    ip : in std_logic_vector((26 - 1) downto 0);
    op : out std_logic_vector((26 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'scale_f01f7ce486',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  local *wrapup = $Sg::{'wrapup'};
  push(@$results, &Sg::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgDeliverFile::{'wrapup'};
  push(@$results, &SgDeliverFile::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgGenerateCores::{'wrapup'};
  push(@$results, &SgGenerateCores::wrapup())   if (defined(&wrapup));
  use Carp qw(croak);
  $ENV{'SYSGEN'} = '/opt/Xilinx/14.6/ISE_DS/ISE/sysgen';
  open(RESULTS, '> /opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/script_results1374667215180442114') || 
    croak 'couldn\'t open /opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/script_results1374667215180442114';
  binmode(RESULTS);
  print RESULTS &Sg::toString($results) . "\n";
  close(RESULTS) || 
    croak 'trouble writing /opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/script_results1374667215180442114';
};

if ($@) {
  open(RESULTS, '> /opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/script_results1374667215180442114') || 
    croak 'couldn\'t open /opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/script_results1374667215180442114';
  binmode(RESULTS);
  print RESULTS $@ . "\n";
  close(RESULTS) || 
    croak 'trouble writing /opt/ptcs/scratch/models/gjones/latest/vegas_devel/mdls/h1k/pfb4t11_bb/sysgen/script_results1374667215180442114';
  exit(1);
}

exit(0);
